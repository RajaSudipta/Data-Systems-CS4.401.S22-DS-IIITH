#include "global.h"
// #include "sparseMatrixCatalogue.h"

bool SparseMatrixCatalogue::isMatrix(const string& matrixName)
{
    logger.log("SparseMatrixCatalogue::isMatrix"); 
    if (this->sparseMatrixMap.count(matrixName))
        return true;
    return false;
}

void SparseMatrixCatalogue::insertMatrix(SparseMatrix* sparseMatrix)
{
    this->sparseMatrixMap[sparseMatrix->matrixName] = sparseMatrix;
}

SparseMatrix* SparseMatrixCatalogue::getMatrix(const string& sparseMatrixName)
{
    return this->sparseMatrixMap[sparseMatrixName];
}