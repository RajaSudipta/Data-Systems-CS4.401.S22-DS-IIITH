#include"page.h"
#include"matrixPage.h"
// #include "sparseMatrix.h"
#include "sparseMatrixPage.h"

class BufferManager{

    deque<Page> pages;
    unordered_map<string, MatrixPage> matrixPages; 
    unordered_map<string, SparseMatrixPage> sparseMatrixPages; 
    bool inPool(string pageName);
    bool inMatrixPool(string pageName);
    Page getFromPool(string pageName);
    Page insertIntoPool(string tableName, int pageIndex);

    public:
    
    BufferManager();
    Page getPage(string tableName, int pageIndex);
    void writePage(string pageName, vector<vector<int>> rows);
    void deleteFile(string tableName, int pageIndex);
    void deleteFile(string fileName);
    void writePage(string tableName, int pageIndex, vector<vector<int>> rows, int rowCount);
    void writeMatrixPage(const string& matrixName, int pageRowIndex, int pageColIndex, vector<vector<int>>& matrix);
    void writeSparseMatrixPage(const string& matrixName, int pageRowIndex, vector<vector<int>>& matrix);
    MatrixPage getMatrixPage(const string& matrixName, int rowIndex, int colIndex);
    string getMatrixPageName(string matrixName, int pageRowIndex, int pageColIndex);
    MatrixPage getMatrixPageFromPool(const string& pageName);
    MatrixPage insertMatrixPageIntoPool(const string& matrixName, const string& pageName, int rowIndex, int colIndex);
    void pushMatrixPageIntoPool(MatrixPage matrixPage);
    void pushSparseMatrixPageIntoPool(SparseMatrixPage sparseMatrixPage);
    vector<vector<int>> readMatrixPageFromTemp(const string& pageName);
    void writeMatrixPageIntoTemp(MatrixPage matrixPage);
    void writeSparseMatrixPageIntoTemp(SparseMatrixPage sparseMatrixPage);
    SparseMatrixPage getSparseMatrixPage(const string& matrixName, int rowIndex);
    string getSparseMatrixPageName(string matrixName, int pageRowIndex);
    bool inSparseMatrixPool(string pageName);
    vector<vector<int>> readSparseMatrixPageFromTemp(const string& pageName);
    SparseMatrixPage insertSparseMatrixPageIntoPool(const string& matrixName, const string& pageName, 
                                                    int rowIndex);
    SparseMatrixPage getSparseMatrixPageFromPool(const string& pageName);
};