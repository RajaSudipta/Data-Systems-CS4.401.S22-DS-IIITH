#include"executor.h"
#include "sparseMatrixCatalogue.h"

extern float BLOCK_SIZE;
extern vector<string> tokenizedQuery;
extern uint PRINT_COUNT;
extern ParsedQuery parsedQuery;
extern int SUBMATRIX_DIM;
extern int SPARSEMATRIX_DIM;
extern TableCatalogue tableCatalogue;
extern MatrixCatalogue matrixCatalogue;
extern SparseMatrixCatalogue sparseMatrixCatalogue;
extern uint BLOCK_COUNT;
extern BufferManager bufferManager;