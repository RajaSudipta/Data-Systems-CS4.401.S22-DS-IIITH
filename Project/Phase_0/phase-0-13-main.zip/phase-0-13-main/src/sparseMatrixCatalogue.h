#include "sparseMatrix.h"

class SparseMatrixCatalogue
{

    unordered_map<string, SparseMatrix*> sparseMatrixMap;

public:
    SparseMatrixCatalogue() {};
    void insertMatrix(SparseMatrix* matrix);
    SparseMatrix* getMatrix(const string& matrixName);
    bool isMatrix(const string& sparseMatrixName);
};
