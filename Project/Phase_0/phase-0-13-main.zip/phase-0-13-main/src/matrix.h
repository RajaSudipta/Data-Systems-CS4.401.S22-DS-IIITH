#define ROWS_AT_ONCE 5

class Matrix {
   private:
    void writeLine(const vector<vector<int>>& line, ofstream& fout);
    void setConfig(const string& line);

   public:
    long long int blockCount;
    string sourceFileName = "";
    long long int dimension;
    string matrixName = "";

    bool blockify(string matrixName);
    Matrix(const string& tableName);

    bool load();
    void transpose();
    void makePermanent();
    void cross_transpose(string matrixName2);
    void print(int blockCount, int dimension);
    Matrix();
};