#ifndef __MATRIXCATALOGUE_H
#define __MATRIXCATALOGUE_H

#include "matrix.h"

class MatrixCatalogue
{

    unordered_map<string, Matrix*> matrixMap;

public:
    MatrixCatalogue() {};
    void insertMatrix(Matrix* matrix);
    Matrix* getMatrix(const string& matrixName);
    bool isMatrix(const string& matrixName);
    // ~MatrixCatalogue();
};

#endif