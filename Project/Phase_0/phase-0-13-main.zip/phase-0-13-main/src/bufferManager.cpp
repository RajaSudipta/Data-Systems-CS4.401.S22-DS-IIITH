#include "global.h"
// #include "sparseMatrix.h"
// #include "sparseMatrixPage.h"

BufferManager::BufferManager()
{
    logger.log("BufferManager::BufferManager");
}

/**
 * @brief Function called to read a page from the buffer manager. If the page is
 * not present in the pool, the page is read and then inserted into the pool.
 *
 * @param tableName 
 * @param pageIndex 
 * @return Page 
 */
Page BufferManager::getPage(string tableName, int pageIndex)
{
    logger.log("BufferManager::getPage");
    string pageName = "../data/temp/"+tableName + "_Page" + to_string(pageIndex);
    if (this->inPool(pageName))
        return this->getFromPool(pageName);
    else
        return this->insertIntoPool(tableName, pageIndex);
}

/**
 * @brief Checks to see if a page exists in the pool
 *
 * @param pageName 
 * @return true 
 * @return false 
 */
bool BufferManager::inPool(string pageName)
{
    logger.log("BufferManager::inPool");
    for (auto page : this->pages)
    {
        if (pageName == page.pageName)
            return true;
    }
    return false;
}

bool BufferManager::inMatrixPool(string pageName)
{
    logger.log("BufferManager::inPool");
    //cout << "size of queue "  << this->matrixPages.size() << endl;
    if(this->matrixPages.find(pageName) == this->matrixPages.end()) {
        return false;
    }
    return true;
}

bool BufferManager::inSparseMatrixPool(string pageName)
{
    logger.log("BufferManager::inPool");
    //cout << "size of queue "  << this->matrixPages.size() << endl;
    if(this->sparseMatrixPages.find(pageName) == this->sparseMatrixPages.end()) {
        return false;
    }
    return true;
}

/**
 * @brief If the page is present in the pool, then this function returns the
 * page. Note that this function will fail if the page is not present in the
 * pool.
 *
 * @param pageName 
 * @return Page 
 */
Page BufferManager::getFromPool(string pageName)
{
    logger.log("BufferManager::getFromPool");
    for (auto page : this->pages) {
        if (pageName == page.pageName)
            return page;
    }
}


MatrixPage BufferManager::getMatrixPageFromPool(const string& pageName)
{
    MatrixPage retrievedPage;
    //cout << "inside function getMatrixPageFromPool" << endl;
    logger.log("BufferManager::getMatrixPageFromPool");

    if(this->matrixPages.find(pageName) == this->matrixPages.end()) {
        return retrievedPage;
    }
    retrievedPage = this->matrixPages[pageName];
    return retrievedPage;
}

SparseMatrixPage BufferManager::getSparseMatrixPageFromPool(const string& pageName)
{
    SparseMatrixPage retrievedPage;
    //cout << "inside function getMatrixPageFromPool" << endl;
    logger.log("BufferManager::getMatrixPageFromPool");

    if(this->sparseMatrixPages.find(pageName) == this->sparseMatrixPages.end()) {
        return retrievedPage;
    }
    retrievedPage = this->sparseMatrixPages[pageName];
    return retrievedPage;
}

/**
 * @brief Inserts page indicated by tableName and pageIndex into pool. If the
 * pool is full, the pool ejects the oldest inserted page from the pool and adds
 * the current page at the end. It naturally follows a queue data structure. 
 *
 * @param tableName 
 * @param pageIndex 
 * @return Page 
 */
Page BufferManager::insertIntoPool(string tableName, int pageIndex)
{
    logger.log("BufferManager::insertIntoPool");
    Page page(tableName, pageIndex);
    if (this->pages.size() >= BLOCK_COUNT)
        pages.pop_front();
    pages.push_back(page);
    return page;
}



/**
 * @brief The buffer manager is also responsible for writing pages. This is
 * called when new tables are created using assignment statements.
 *
 * @param tableName 
 * @param pageIndex 
 * @param rows 
 * @param rowCount 
 */
void BufferManager::writePage(string tableName, int pageIndex, vector<vector<int>> rows, int rowCount)
{
    logger.log("BufferManager::writePage");
    Page page(tableName, pageIndex, rows, rowCount);
    page.writePage();
}

void BufferManager::writeMatrixPageIntoTemp(MatrixPage matrixPage)
{
    logger.log("BufferManager::writeMatrixPage");
    matrixPage.writeMatrixPage();
}

void BufferManager::writeSparseMatrixPageIntoTemp(SparseMatrixPage sparseMatrixPage)
{
    logger.log("BufferManager::writeMatrixPage");
    sparseMatrixPage.writeMatrixPage();
}

void BufferManager::pushMatrixPageIntoPool(MatrixPage matrixPage) {
    // already in buffer
    if(this->matrixPages.find(matrixPage.getPageName()) == this->matrixPages.end()) {
        if (this->matrixPages.size() >= BLOCK_COUNT && !this->matrixPages.empty()) {
            this->matrixPages.erase(this->matrixPages.begin()->first);
        }
        this->matrixPages[matrixPage.getPageName()] = matrixPage;

        return;
    }

    this->matrixPages[matrixPage.getPageName()].setMatrix(matrixPage.getMatrix());
}

void BufferManager::pushSparseMatrixPageIntoPool(SparseMatrixPage sparseMatrixPage) {
    // already in buffer
    if(this->sparseMatrixPages.find(sparseMatrixPage.getPageName()) == this->sparseMatrixPages.end()) {
        if (this->sparseMatrixPages.size() >= BLOCK_COUNT && !this->sparseMatrixPages.empty()) {
            this->sparseMatrixPages.erase(this->matrixPages.begin()->first);
        }
        this->sparseMatrixPages[sparseMatrixPage.getPageName()] = sparseMatrixPage;

        return;
    }

    this->matrixPages[sparseMatrixPage.getPageName()].setMatrix(sparseMatrixPage.getMatrix());
}

/**
 * @brief The buffer manager is also responsible for writing pages. This is
 * called when new tables are created using assignment statements.
 *
 * @param tableName 
 * @param pageIndex 
 * @param rows 
 * @param rowCount 
 */
void BufferManager::writeMatrixPage(const string& matrixName, int pageRowIndex, 
                                    int pageColIndex, vector<vector<int>>& matrix)
{
    logger.log("BufferManager::writeMatrixPage");
    MatrixPage matrixPage(matrixName, pageRowIndex, pageColIndex, matrix);
    this->pushMatrixPageIntoPool(matrixPage); // IMP, uncomment it
    this->writeMatrixPageIntoTemp(matrixPage); // IMP, uncomment it
}

void BufferManager::writeSparseMatrixPage(const string& matrixName, int pageRowIndex, vector<vector<int>>& matrix)
{
    logger.log("BufferManager::writeSparseMatrixPage");
    SparseMatrixPage sparseMatrixPage(matrixName, pageRowIndex, matrix);
    this->pushSparseMatrixPageIntoPool(sparseMatrixPage); // IMP, uncomment it
    this->writeSparseMatrixPageIntoTemp(sparseMatrixPage); // IMP, uncomment it
}

string BufferManager::getMatrixPageName(string matrixName, int pageRowIndex, int pageColIndex)
{
    string pageName = ("../data/temp/Matrix_" + (matrixName) + "-Page_" + to_string(pageRowIndex) + "_" + to_string(pageColIndex));

    return pageName;
}

vector<vector<int>> BufferManager::readMatrixPageFromTemp(const string& pageName) {
    fstream fin(pageName, ios::in);
    int number;

    vector<vector<int>> matrix (SUBMATRIX_DIM, vector<int> (SUBMATRIX_DIM, -1));
    int rowCounter = 0, columnCounter = 0;
    while (rowCounter < SUBMATRIX_DIM)
    {
        columnCounter = 0;
        while (columnCounter < SUBMATRIX_DIM)
        {
            fin >> number;
            matrix[rowCounter][columnCounter] = number;
            columnCounter++;
        }
        rowCounter++;
    }
    fin.close();

    return matrix;
}

vector<vector<int>> BufferManager::readSparseMatrixPageFromTemp(const string& pageName) {
    fstream fin(pageName, ios::in);
    int number;

    vector<vector<int>> matrix (SPARSEMATRIX_DIM, vector<int> (3, -1));
    int rowCounter = 0, columnCounter = 0;
    while (rowCounter < SPARSEMATRIX_DIM)
    {
        columnCounter = 0;
        while (columnCounter < 3)
        {
            fin >> number;
            matrix[rowCounter][columnCounter] = number;
            columnCounter++;
        }
        rowCounter++;
    }
    fin.close();

    return matrix;
}

MatrixPage BufferManager::insertMatrixPageIntoPool(const string& matrixName, const string& pageName, 
                                                    int rowIndex, int colIndex) {
    logger.log("BufferManager::insertMatrixPageIntoPool");
    vector<vector<int>> matrix = this->readMatrixPageFromTemp(pageName);

    //cout << "loaded matrix " << matrix.size() << endl;

    MatrixPage matrixPage(matrixName, rowIndex, colIndex, matrix);

    // MatrixPage matrixPage(matrixName, rowIndex, colIndex);

    this->pushMatrixPageIntoPool(matrixPage);

    return matrixPage;
}

SparseMatrixPage BufferManager::insertSparseMatrixPageIntoPool(const string& matrixName, const string& pageName, 
                                                    int rowIndex) {
    logger.log("BufferManager::insertSparseMatrixPageIntoPool");
    vector<vector<int>> matrix = this->readSparseMatrixPageFromTemp(pageName);

    //cout << "loaded matrix " << matrix.size() << endl;

    SparseMatrixPage sparseMatrixPage(matrixName, rowIndex, matrix);

    // MatrixPage matrixPage(matrixName, rowIndex, colIndex);

    this->pushSparseMatrixPageIntoPool(sparseMatrixPage);

    return sparseMatrixPage;
}

MatrixPage BufferManager::getMatrixPage(const string& matrixName, int rowIndex, int colIndex) {
    logger.log("BufferManager::getMatrixPage");
    string pageName = this->getMatrixPageName(matrixName, rowIndex, colIndex);

    // Check for page in pool, if present return if not then read it from Temp folder
    if (!this->inMatrixPool(pageName)) {
        return this->insertMatrixPageIntoPool(matrixName, pageName, rowIndex, colIndex);
    } else {
        return this->getMatrixPageFromPool(pageName);
    }
}

string BufferManager::getSparseMatrixPageName(string matrixName, int pageRowIndex)
{
    string pageName = ("../data/temp/Matrix_" + (matrixName) + "-Page_" + to_string(pageRowIndex));
    return pageName;
}

SparseMatrixPage BufferManager::getSparseMatrixPage(const string& matrixName, int rowIndex) {
    logger.log("BufferManager::getSparseMatrixPage");
    string pageName = this->getSparseMatrixPageName(matrixName, rowIndex);

    // Check for page in pool, if present return if not then read it from Temp folder
    if (!this->inSparseMatrixPool(pageName)) {
        return this->insertSparseMatrixPageIntoPool(matrixName, pageName, rowIndex);
    } else {
        return this->getSparseMatrixPageFromPool(pageName);
    }
}


/**
 * @brief Deletes file names fileName
 *
 * @param fileName 
 */
void BufferManager::deleteFile(string fileName)
{
    
    if (remove(fileName.c_str()))
        logger.log("BufferManager::deleteFile: Err");
        else logger.log("BufferManager::deleteFile: Success");
}

/**
 * @brief Overloaded function that calls deleteFile(fileName) by constructing
 * the fileName from the tableName and pageIndex.
 *
 * @param tableName 
 * @param pageIndex 
 */
void BufferManager::deleteFile(string tableName, int pageIndex)
{
    logger.log("BufferManager::deleteFile");
    string fileName = "../data/temp/"+tableName + "_Page" + to_string(pageIndex);
    this->deleteFile(fileName);
}