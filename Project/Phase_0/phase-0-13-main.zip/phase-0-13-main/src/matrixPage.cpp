#include "global.h"

string MatrixPage::getMatrixPageName(string matrixName, int pageRowIndex, int pageColIndex)
{
    string pageName = ("../data/temp/Matrix_" + (matrixName) + "-Page_" + to_string(pageRowIndex) + "_" + to_string(pageColIndex));

    return pageName;
}

string MatrixPage::getPageName() {
    return this->pageName;
}

MatrixPage::MatrixPage(const string& matrixName, int pageRowIndex, 
                        int pageColIndex, vector<vector<int>>& matrix) {
    logger.log("MatrixPage::MatrixPage");

    this->matrixName = matrixName;
    this->pageRowIndex = pageRowIndex;
    this->pageColIndex = pageColIndex;
    this->pageName = this->getMatrixPageName(this->matrixName, this->pageRowIndex, this->pageColIndex);

    this->matrix = matrix;
}

void MatrixPage::generateMatrixFromTemp()
{
    this->matrix.resize(SUBMATRIX_DIM);
    fill(this->matrix.begin(), this->matrix.end(), vector<int>(SUBMATRIX_DIM, -1));

    ifstream fin(this->pageName, ios::in);
    int i = 0, j = 0;
    int temp;
    while (i < SUBMATRIX_DIM) {
        j = 0;
        while (j < SUBMATRIX_DIM) {
            fin >> temp;
            this->matrix[i][j] = temp;
            j++;
        }
        i++;
    }
}

MatrixPage::MatrixPage(const string& matrixName, int rowIndex, int colIndex) {
    logger.log("MatrixPage::MatrixPage");

    this->pageColIndex = colIndex;
    this->pageName = this->getMatrixPageName(this->matrixName, this->pageRowIndex, this->pageColIndex);
    this->matrixName = matrixName;
    this->pageRowIndex = rowIndex;

    this->generateMatrixFromTemp();
}

vector<vector<int>> MatrixPage::getMatrix()
{
    return this->matrix;
} 

string MatrixPage::getMatrixDetails()
{
    string str = this->matrixName + " ";
    str += to_string(this->pageRowIndex) + " ";
    str += to_string(this->pageColIndex);
    str += this->pageName;
    return str;
}

void MatrixPage::writeMatrixPage()
{
    logger.log("Page::writeMatrixPage");
    ofstream fout(this->pageName, ios::trunc);
    int rowCounter = 0, columnCounter = 0;
    while (rowCounter < SUBMATRIX_DIM)
    {
        columnCounter = 0;
        while (columnCounter < SUBMATRIX_DIM)
        {
            if (columnCounter != 0)
                fout << " ";
            fout << this->matrix[rowCounter][columnCounter];
            columnCounter++;
        }
        fout << endl;
        rowCounter++;
    }
    fout.close();
}

void MatrixPage::setMatrix(vector<vector<int>> matrix) 
{
    this->matrix = matrix;
}