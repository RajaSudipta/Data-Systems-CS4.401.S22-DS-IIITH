#include"global.h"

bool semanticParse(){
    logger.log("semanticParse");
    switch(parsedQuery.queryType){
        case CLEAR: return semanticParseCLEAR();
        case CROSS: return semanticParseCROSS();
        case DISTINCT: return semanticParseDISTINCT();
        case EXPORT: return semanticParseEXPORT();
        case EXPORTMATRIX: return semanticParseEXPORTMATRIX();
        case INDEX: return semanticParseINDEX();
        case JOIN: return semanticParseJOIN();
        case LIST: return semanticParseLIST();
        case LOAD: return semanticParseLOAD();
        case LOAD_MATRIX: return semanticParseLOADMATRIX();
        case LOAD_SPARSE_MATRIX: return semanticParseLOADSPARSEMATRIX();
        case PRINT: return semanticParsePRINT();
        case PRINT_MATRIX: return semanticParsePRINTMATRIX();
        case PRINT_SPARSE_MATRIX: return semanticParsePRINTSPARSEMATRIX();
        case PROJECTION: return semanticParsePROJECTION();
        case RENAME: return semanticParseRENAME();
        case SELECTION: return semanticParseSELECTION();
        case SORT: return semanticParseSORT();
        case SOURCE: return semanticParseSOURCE();
        case TRANSPOSE: return semanticParseTRANSPOSE();
        case SPARSE_TRANSPOSE: return semanticParseSPARSETRANSPOSE();
        case CROSS_TRANSPOSE: return semanticParseCROSSTRANSPOSE();
        default: cout<<"SEMANTIC ERROR"<<endl;
    }

    return false;
}