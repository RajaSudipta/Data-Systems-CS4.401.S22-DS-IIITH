#include "global.h"
// #include "sparseMatrixPage.h"

string SparseMatrixPage::getMatrixPageName(string matrixName, int pageRowIndex)
{
    string pageName = ("../data/temp/Matrix_" + (matrixName) + "-Page_" + to_string(pageRowIndex));
    return pageName;
}

string SparseMatrixPage::getPageName() {
    return this->pageName;
}

SparseMatrixPage::SparseMatrixPage(const string& matrixName, int pageRowIndex, vector<vector<int>>& matrix) {
    logger.log("MatrixPage::MatrixPage");

    this->matrixName = matrixName;
    this->pageRowIndex = pageRowIndex;
    this->pageName = this->getMatrixPageName(this->matrixName, this->pageRowIndex);
    this->matrix = matrix;
}

void SparseMatrixPage::generateMatrixFromTemp()
{
    this->matrix.resize(SUBMATRIX_DIM);
    fill(this->matrix.begin(), this->matrix.end(), vector<int>(SUBMATRIX_DIM, -1));

    ifstream fin(this->pageName, ios::in);
    int i = 0, j = 0;
    int temp;
    while (i < SUBMATRIX_DIM) {
        j = 0;
        while (j < SUBMATRIX_DIM) {
            fin >> temp;
            this->matrix[i][j] = temp;
            j++;
        }
        i++;
    }
}


vector<vector<int>> SparseMatrixPage::getMatrix()
{
    return this->matrix;
} 


void SparseMatrixPage::writeMatrixPage()
{
    logger.log("Page::writeMatrixPage");
    ofstream fout(this->pageName, ios::trunc);
    int rowCounter = 0, columnCounter = 0;
    while (rowCounter < SPARSEMATRIX_DIM)
    {
        columnCounter = 0;
        while (columnCounter < 3)
        {
            if (columnCounter != 0)
                fout << " ";
            fout << this->matrix[rowCounter][columnCounter];
            columnCounter++;
        }
        fout << endl;
        rowCounter++;
    }
    fout.close();
}

void SparseMatrixPage::setMatrix(vector<vector<int>> matrix) 
{
    this->matrix = matrix;
}