#include"syntacticParser.h"

bool semanticParse();

bool semanticParseCLEAR();
bool semanticParseCROSS();
bool semanticParseDISTINCT();
bool semanticParseEXPORT();
bool semanticParseEXPORTMATRIX();
bool semanticParseINDEX();
bool semanticParseJOIN();
bool semanticParseLIST();
bool semanticParseLOAD();
bool semanticParseLOADMATRIX();
bool semanticParseLOADSPARSEMATRIX();
bool semanticParsePRINT();
bool semanticParsePRINTMATRIX();
bool semanticParsePRINTSPARSEMATRIX();
bool semanticParsePROJECTION();
bool semanticParseRENAME();
bool semanticParseSELECTION();
bool semanticParseSORT();
bool semanticParseSOURCE();
// bool syntacticParseTRANSPOSE();
bool semanticParseTRANSPOSE();
bool semanticParseSPARSETRANSPOSE();
bool semanticParseCROSSTRANSPOSE();

