#include "global.h"

bool MatrixCatalogue::isMatrix(const string& matrixName)
{
    logger.log("MatrixCatalogue::isMatrix"); 
    if (this->matrixMap.count(matrixName))
        return true;
    return false;
}

void MatrixCatalogue::insertMatrix(Matrix* matrix)
{
    this->matrixMap[matrix->matrixName] = matrix;
}

Matrix* MatrixCatalogue::getMatrix(const string& matrixName)
{
    return this->matrixMap[matrixName];
}