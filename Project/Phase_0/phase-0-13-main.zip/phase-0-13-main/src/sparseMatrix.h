#define ROWS_AT_ONCE 5

class SparseMatrix {
   private:
    vector<int> readMatrixLine(const string& line, int colNo);
    void writeLine(const vector<vector<int>>& line, ofstream& fout);
    void setConfig(const string& line);

   public:
    long long int blockCount;
    string sourceFileName = "";
    long long int dimension;
    string matrixName = "";
    int total_non_zero_values;

    bool blockify(string matrixName);
    SparseMatrix(const string& tableName);

    bool load();
    void transpose();
    void makePermanent();
    void print(int blockCount, int dimension);
    string lltrim(const string &s);
    string rrtrim(const string &s);
    string ttrim(const string &s);
    SparseMatrix();
    void sparse_transpose();
    void print();
};