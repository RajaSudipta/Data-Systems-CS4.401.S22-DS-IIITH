//Server Code
#include "global.h"

using namespace std;

float BLOCK_SIZE = 8;
uint BLOCK_COUNT = 5;
uint PRINT_COUNT = 20;
int SUBMATRIX_DIM = (int)sqrt((BLOCK_SIZE * 1024) / sizeof(int));
int SPARSEMATRIX_DIM = (int)((BLOCK_SIZE * 1024) / (3 * sizeof(int)));
Logger logger;
vector<string> tokenizedQuery;
ParsedQuery parsedQuery;
TableCatalogue tableCatalogue;
MatrixCatalogue matrixCatalogue;
SparseMatrixCatalogue sparseMatrixCatalogue;
BufferManager bufferManager;
// int SUBMATRIX_DIM;

void doCommand()
{
    logger.log("doCommand");
    if (syntacticParse() && semanticParse())
        executeCommand();
    return;
}

int main(void)
{

    regex delim("[^\\s,]+");
    string command;
    system("rm -rf ../data/temp");
    system("mkdir ../data/temp");

    // SUBMATRIX_DIM = (int)sqrt((BLOCK_SIZE * 1024) / sizeof(int));

    while(!cin.eof())
    {
        cout << "\n> ";
        tokenizedQuery.clear();
        parsedQuery.clear();
        logger.log("\nReading New Command: ");
        getline(cin, command);
        logger.log(command);


        auto words_begin = std::sregex_iterator(command.begin(), command.end(), delim);
        auto words_end = std::sregex_iterator();
        for (std::sregex_iterator i = words_begin; i != words_end; ++i)
            tokenizedQuery.emplace_back((*i).str());

        if (tokenizedQuery.size() == 1 && tokenizedQuery.front() == "QUIT")
        {
            break;
        }

        if (tokenizedQuery.empty())
        {
            continue;
        }

        if (tokenizedQuery.size() == 1)
        {
            cout << "SYNTAX ERROR" << endl;
            continue;
        }

        doCommand();
    }
}