#include "global.h"
// #include "sparseMatrix.h"
// #include "sparseMatrixPage.h"
// #include "sparseMatrixCatalogue.h"

bool semanticParseLOADSPARSEMATRIX()
{
    logger.log("semanticParseLOADMATRIX");
    if (sparseMatrixCatalogue.isMatrix(parsedQuery.loadMatrixName))
    {
        cout << "SEMANTIC ERROR: Matrix already exists" << endl;
        return false;
    }

    // cout << parsedQuery.loadMatrixName << endl;
    if (!isFileExists(parsedQuery.loadMatrixName))
    {
        cout << "SEMANTIC ERROR: Data file doesn't exist" << endl;
        return false;
    }

    if (!isMatrix(parsedQuery.loadMatrixName))
    {
        cout << "SEMANTIC ERROR: The file isn't a matrix" << endl;
        return false;
    }

    return true;
}

void executeSpraseMatrixLOAD() 
{
    logger.log("executeSparseMatrixLOAD");
    SparseMatrix *sparseMatrix = new SparseMatrix(parsedQuery.loadMatrixName);
    if(sparseMatrix->load())
    {
        sparseMatrixCatalogue.insertMatrix(sparseMatrix);
        // cout << "Loaded Matrix. Column Count: " << matrix->dimension << " Row Count: " << matrix->dimension << endl;
    }

    return;
}