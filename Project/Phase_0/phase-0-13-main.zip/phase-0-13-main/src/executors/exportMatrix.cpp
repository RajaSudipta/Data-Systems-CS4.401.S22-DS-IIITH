#include "global.h"

/**
 * @brief 
 * SYNTAX: EXPORT <relation_name> 
 */

bool syntacticParseEXPORTMATRIX()
{
    logger.log("syntacticParseEXPORTMATRIX");
    if (tokenizedQuery.size() != 3)
    {
        cout << "SYNTAX ERROR" << endl;
        return false;
    }
    parsedQuery.queryType = EXPORTMATRIX;
    parsedQuery.exportRelationOrMatrixName = tokenizedQuery[2];
    return true;
}

bool semanticParseEXPORTMATRIX()
{
    logger.log("semanticParseEXPORTMATRIX");
    //Table should exist
    if (matrixCatalogue.isMatrix(parsedQuery.exportRelationOrMatrixName))
        return true;
    cout << "SEMANTIC ERROR: No such relation or matrix exists" << endl;
    return false;
}

void executeEXPORTMATRIX()
{
    logger.log("executeEXPORTMATRIX");
    if(!matrixCatalogue.isMatrix(parsedQuery.exportRelationOrMatrixName))
        return;
    
    Matrix* matrix = matrixCatalogue.getMatrix(parsedQuery.exportRelationOrMatrixName);
    matrix->makePermanent();
}