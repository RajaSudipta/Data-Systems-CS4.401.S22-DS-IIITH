#include "global.h"
/**
 * @brief 
 * SYNTAX: PRINT relation_name
 */
bool syntacticParsePRINTSPARSEMATRIX()
{
    logger.log("syntacticParsePRINTSPARSE");
    if (tokenizedQuery.size() != 4)
    {
        cout << "SYNTAX ERROR" << endl;
        return false;
    }
    parsedQuery.queryType = PRINT_SPARSE_MATRIX;
    parsedQuery.printMatrixName = tokenizedQuery[3];
    return true;
}

bool semanticParsePRINTSPARSEMATRIX()
{
    logger.log("semanticParsePRINTSPARSEMATRIX");
    if (!sparseMatrixCatalogue.isMatrix(parsedQuery.printMatrixName))
    {
        cout << "SEMANTIC ERROR: Matrix doesn't exist" << endl;
        return false;
    }
    return true;
}

void executePRINTSPARSEMATRIX()
{
    logger.log("executePRINTSPARSEMATRIX");
    
    if (!sparseMatrixCatalogue.isMatrix(parsedQuery.printMatrixName))
        return;

    SparseMatrix* sparseMatrix = sparseMatrixCatalogue.getMatrix(parsedQuery.printMatrixName);
    sparseMatrix->print(sparseMatrix->blockCount, sparseMatrix->dimension);
}
