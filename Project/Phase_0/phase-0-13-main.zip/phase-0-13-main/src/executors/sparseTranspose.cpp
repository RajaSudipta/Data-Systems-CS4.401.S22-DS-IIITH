#include "global.h"
/**
 * @brief 
 * SYNTAX: TRANSPOSE matrix_name
 */
bool syntacticParseSPARSETRANSPOSE()
{
    logger.log("syntacticParseSPARSETRANSPOSE");
    if (tokenizedQuery.size() != 3)
    {
        cout << "SYNTAX ERROR" << endl;
        return false;
    }
    parsedQuery.queryType = SPARSE_TRANSPOSE;
    parsedQuery.transposeMatrixName = tokenizedQuery[2];
    return true;
}

bool semanticParseSPARSETRANSPOSE()
{
    logger.log("semanticParseSPARSETRANSPOSE");
    if (sparseMatrixCatalogue.isMatrix(parsedQuery.transposeMatrixName))
    {
        return true;
    }
    else
    {
        cout << "SEMANTIC ERROR: Matrix doesn't exist" << endl;
        return false;
    }

    if (isMatrix(parsedQuery.transposeMatrixName))
    {
        return true;
    }
    else
    {
        cout << "SEMANTIC ERROR: The file isn't a matrix" << endl;
        return false;
    }
}

void executeSPARSETRANSPOSE()
{
    logger.log("executeSPARSETRANSPOSE");
    SparseMatrix* sparseMatrix = sparseMatrixCatalogue.getMatrix(parsedQuery.transposeMatrixName);
    sparseMatrix->sparse_transpose();
    return;
}