#include "global.h"

bool isMatrix(string matrixName)
{
    string fileName = "../data/" + matrixName + ".csv";
    ifstream fin(fileName, ios::in);

    string firstWord;
    getline(fin, firstWord, ',');
    firstWord.erase(std::remove_if(firstWord.begin(), firstWord.end(), ::isspace), firstWord.end());

    try
    {
        stoi(firstWord);
        return true;
    }
    catch (exception e)
    {
        return false;
    }
}

bool semanticParseLOADMATRIX()
{
    logger.log("semanticParseLOADMATRIX");
    if (matrixCatalogue.isMatrix(parsedQuery.loadMatrixName))
    {
        cout << "SEMANTIC ERROR: Matrix already exists" << endl;
        return false;
    }

    // cout << parsedQuery.loadMatrixName << endl;
    if (!isFileExists(parsedQuery.loadMatrixName))
    {
        cout << "SEMANTIC ERROR: Data file doesn't exist" << endl;
        return false;
    }

    if (!isMatrix(parsedQuery.loadMatrixName))
    {
        cout << "SEMANTIC ERROR: The file isn't a matrix" << endl;
        return false;
    }

    return true;
}

void executeMatrixLOAD() 
{
    logger.log("executeMatrixLOAD");
    Matrix *matrix = new Matrix(parsedQuery.loadMatrixName);
    if(matrix->load())
    {
        matrixCatalogue.insertMatrix(matrix);
        cout << "Loaded Matrix. Column Count: " << matrix->dimension << " Row Count: " << matrix->dimension << endl;
    }

    return;
}