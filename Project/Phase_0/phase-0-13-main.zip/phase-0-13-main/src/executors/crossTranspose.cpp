#include "global.h"
/**
 * @brief 
 * SYNTAX: TRANSPOSE matrix_name
 */
bool syntacticParseCROSSTRANSPOSE()
{
    logger.log("syntacticParseCROSS_TRANSPOSE");
    if (tokenizedQuery.size() != 3)
    {
        cout << "SYNTAX ERROR" << endl;
        return false;
    }
    parsedQuery.queryType = CROSS_TRANSPOSE;
    parsedQuery.transposeMatrixName1 = tokenizedQuery[1];
    parsedQuery.transposeMatrixName2 = tokenizedQuery[2];
    return true;
}

bool semanticParseCROSSTRANSPOSE()
{
    logger.log("semanticParseCROSS_TRANSPOSE");
    if (!matrixCatalogue.isMatrix(parsedQuery.transposeMatrixName1))
    {
        cout << "SEMANTIC ERROR: Matrix 1 doesn't exist" << endl;
        return false;
    }

    if (!matrixCatalogue.isMatrix(parsedQuery.transposeMatrixName2))
    {
        cout << "SEMANTIC ERROR: Matrix 2 doesn't exist" << endl;
        return false;
    }

    if (!isMatrix(parsedQuery.transposeMatrixName1))
    {
        cout << "SEMANTIC ERROR: The file 1 isn't a matrix" << endl;
        return false;
    }

    if (!isMatrix(parsedQuery.transposeMatrixName2))
    {
        cout << "SEMANTIC ERROR: The file 2 isn't a matrix" << endl;
        return false;
    }

    return true;
}

void executeCROSSTRANSPOSE()
{
    logger.log("execute CROSS_TRANSPOSE");
    Matrix *matrix = matrixCatalogue.getMatrix(parsedQuery.transposeMatrixName1);
    matrix->cross_transpose(parsedQuery.transposeMatrixName2);
    return;
}