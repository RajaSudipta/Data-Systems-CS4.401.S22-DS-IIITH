class SparseMatrixPage {

    int pageRowIndex;
    vector<vector<int>> matrix;
    string pageName;
    string matrixName;

   public:
    SparseMatrixPage(const string& matrixName, int pageRowIndex);
    vector<vector<int>> getMatrix();
    SparseMatrixPage(){};
    string getMatrixDetails();
    string getPageName();
    void setMatrix(vector<vector<int>> matrix);
    SparseMatrixPage(const string& matrixName, int pageRowIndex, vector<vector<int>>& data);
    string getMatrixPageName(string matrixName, int pageRowIndex);
    void writeMatrixPage();
    void generateMatrixFromTemp();
};