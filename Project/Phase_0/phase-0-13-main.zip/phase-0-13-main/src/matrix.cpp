#include "global.h"

const string WHITESPACE = " \n\r\t\f\v";

string ltrim(const string &s)
{
    size_t start = s.find_first_not_of(WHITESPACE);
    return (start == std::string::npos) ? "" : s.substr(start);
}
 
string rtrim(const string &s)
{
    size_t end = s.find_last_not_of(WHITESPACE);
    return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}

std::string trim(const std::string &s) 
{
    return rtrim(ltrim(s));
}

Matrix::Matrix(const string& matrixName)
{
    logger.log("Matrix::Matrix");
    this->sourceFileName = "../data/" + matrixName + ".csv";
    this->matrixName = matrixName;
}

/**
 * @brief The load function is used when the LOAD command is encountered. It
 * reads data from the source file, splits it into blocks
 *
 * @return true if the matrix has been successfully loaded 
 * @return false if an error occurred 
 */
bool Matrix::load() 
{
	logger.log("Matrix::load");
	fstream fin(this->sourceFileName, ios::in);
	string line;
	if(this->blockify(this->matrixName))
		return true;

	return false;
}

vector<int> get_1d_vec_from_line(string line, int length)
{
    vector<int> tokens;
    stringstream ss(line);
    string temp;
    while(getline(ss, temp, ','))
    {
        string trimmed = trim(temp);
        tokens.push_back(stoi(trimmed));
    }

    while(tokens.size() < length)
    {
        tokens.push_back(-1);
    }
    return tokens;
}

bool Matrix::blockify(string matrixName)
{
	ifstream fin(this->sourceFileName, ios::in);

	if (fin.peek() == ifstream::traits_type::eof()) 
	{
        cout << "BAD REQUEST: File is empty." << endl;
        return false;
    }

    string line;
    getline(fin, line);
    this->setConfig(line);

    fin.close();

    int vec_2d_col_size;

    if(dimension % SUBMATRIX_DIM == 0)
    {
        vec_2d_col_size = dimension;
    }
    else
    {
        int d = (dimension/SUBMATRIX_DIM) + 1;
        vec_2d_col_size = (SUBMATRIX_DIM * d);
    }

    vector<vector<int>> vec2d (SUBMATRIX_DIM, vector<int> (vec_2d_col_size, -1));
    vector<int> vec1d(vec_2d_col_size, -1);
    int row_counter = 0;
    int line_counter = 0;

    ifstream fin2(this->sourceFileName, ios::in);

    while (getline(fin2, line))
    {
        // cout << "line: " << line << endl;
        if(row_counter == SUBMATRIX_DIM)
        {
            row_counter = 0;

            // for(auto it: vec2d)
            // {
            //     for(auto it2: it)
            //     {
            //         cout << it2 << " ";
            //     }
            //     cout << endl << endl;
            // }

            /* divide the large vector into sub vector and write in pages */
            vector<vector<int>> temp(SUBMATRIX_DIM, vector<int>(SUBMATRIX_DIM, -1));
            for(int i=0; i<vec_2d_col_size; i++)
            {
                for(int j=0; j<SUBMATRIX_DIM; j++)
                {
                    temp[j%SUBMATRIX_DIM][i%SUBMATRIX_DIM] = vec2d[j][i]; 
                    if(i%SUBMATRIX_DIM==SUBMATRIX_DIM-1 && j==SUBMATRIX_DIM-1)
                    {
                        // for(auto it: temp)
                        // {
                        //     for(auto it2: it)
                        //     {
                        //         cout << it2 << " ";
                        //     }
                        //     cout << endl << endl;
                        // }
                        int page_row = ceil((float)line_counter/(float)SUBMATRIX_DIM) - 1;
                        int page_col = i/SUBMATRIX_DIM;
                        // cout << "page_row: " << page_row << ", page_col: " << page_col << endl;
                        bufferManager.writeMatrixPage(this->matrixName, page_row, page_col, temp);
                        temp.assign(SUBMATRIX_DIM, vector<int>(SUBMATRIX_DIM, -1));
                    }
                }
            }

            vec2d.assign(SUBMATRIX_DIM, vector<int> (vec_2d_col_size, -1));

        }
        vec1d = get_1d_vec_from_line(line, vec_2d_col_size);
        vec2d[row_counter] = vec1d;
        row_counter++;
        line_counter++;
    }

    fin2.close();

    // if(dimension%SUBMATRIX_DIM == 0)
    // {
        // cout << "Last block" << endl;
        // for(auto it: vec2d)
        // {
        //     for(auto it2: it)
        //     {
        //         cout << it2 << " ";
        //     }
        //     cout << endl << endl;
        // }
        /* write the last vector into sub vector and write in pages  */
        vector<vector<int>> temp(SUBMATRIX_DIM, vector<int>(SUBMATRIX_DIM, -1));
        for(int i=0; i<vec_2d_col_size; i++)
        {
            for(int j=0; j<SUBMATRIX_DIM; j++)
            {
                temp[j%SUBMATRIX_DIM][i%SUBMATRIX_DIM] = vec2d[j][i]; 
                if(i%SUBMATRIX_DIM==SUBMATRIX_DIM-1 && j==SUBMATRIX_DIM-1)
                {
                    // for(auto it: temp)
                    // {
                    //     for(auto it2: it)
                    //     {
                    //         cout << it2 << " ";
                    //     }
                    //     cout << endl << endl;
                    // }
                    int page_row = ceil((float)line_counter/(float)SUBMATRIX_DIM) - 1;
                    int page_col = i/SUBMATRIX_DIM;
                    // cout << "page_row: " << paage_row << ", page_col: " << page_col << endl;
                    bufferManager.writeMatrixPage(this->matrixName, page_row, page_col, temp);
                    temp.assign(SUBMATRIX_DIM, vector<int>(SUBMATRIX_DIM, -1));
                }
            }
        }
    // }

    return true;
}

void Matrix::setConfig(const string& line)
{
	logger.log("Matrix::setConfig");
	int count = 0;
    int x = 0;
    for (auto& c: line) {
        if (c == ',') {
            count++;
        }
        else {
            x++;
        }
    }
    x = x%SUBMATRIX_DIM;
    if (line.back() != ',') {
        x++;
        count++;
    }
    this->dimension = count;
    count = dimension;
    this->blockCount = ceil((double)(this->dimension)/(double)(SUBMATRIX_DIM));
}

void Matrix::transpose()
{
    /* blocks on diagonal */
    int row_index = 0;
    while(row_index<this->blockCount)
    {
        MatrixPage current_page = bufferManager.getMatrixPage(this->matrixName, row_index, row_index);
        vector<vector<int>> current_matrix = current_page.getMatrix();
        
        // transposing inside the matrix
        for (int i = 0; i < SUBMATRIX_DIM; i++)
        {
            for (int j = i + 1; j < SUBMATRIX_DIM; j++)
            {
                int temp = current_matrix[i][j];
                current_matrix[i][j] = current_matrix[j][i];
                current_matrix[j][i] = temp;
            }
        }
        
        bufferManager.writeMatrixPage(this->matrixName, row_index, row_index, current_matrix);
        row_index++;
    }

    /* other blocks like (0,1) */
    row_index = 0;
    while (row_index < this->blockCount)
    {
        for (int col_index = row_index + 1; col_index < this->blockCount; col_index++)
        {
            
            MatrixPage page1 = bufferManager.getMatrixPage(this->matrixName, row_index, col_index);  
            MatrixPage page2 = bufferManager.getMatrixPage(this->matrixName, col_index, row_index);

            vector<vector<int>> matrix1 = page1.getMatrix();
            vector<vector<int>> matrix2 = page2.getMatrix();

            // transposing inside the matrices
            for(int i=0; i<SUBMATRIX_DIM; i++)
            {
                for(int j=0; j<SUBMATRIX_DIM; j++)
                {
                    swap(matrix1[i][j], matrix2[j][i]);
                }
            }

            bufferManager.writeMatrixPage(this->matrixName, row_index, col_index, matrix1);
            bufferManager.writeMatrixPage(this->matrixName, col_index, row_index, matrix2);
        }
        row_index++;
    }
}

void Matrix::cross_transpose(string matrixName2)
{
    /* CROSS_TRANSPOSE A A -> TRANSPOSE A */
    if(this->matrixName == matrixName2)
    {
        transpose();
    }
    else
    {
        for (int rowIndex = 0; rowIndex < this->blockCount; rowIndex++)
        {
            for (int colIndex = 0; colIndex < this->blockCount; colIndex++)
            {
                //cout << "getting page " << rowIndex << " " << colIndex << endl; 
                MatrixPage currentPage = bufferManager.getMatrixPage(this->matrixName, rowIndex, colIndex);  
                MatrixPage swapPage = bufferManager.getMatrixPage(matrixName2, colIndex, rowIndex);

                vector<vector<int>> currentMatrix = currentPage.getMatrix();
                vector<vector<int>> swapMatrix = swapPage.getMatrix();

                for(int i=0; i<SUBMATRIX_DIM; i++)
                {
                    for(int j=0; j<SUBMATRIX_DIM; j++)
                    {
                        swap(currentMatrix[i][j], swapMatrix[j][i]);
                    }
                }

                bufferManager.writeMatrixPage(this->matrixName, rowIndex, colIndex, currentMatrix);
                bufferManager.writeMatrixPage(matrixName2, colIndex, rowIndex, swapMatrix);

                // cout << "swap Matrix 1 (" << rowIndex << ", " << colIndex << ") <-> Matrix 2 (" << colIndex << ", " << rowIndex << ") done" << endl;

            }
        }
    }
}

void Matrix::writeLine(const vector<vector<int>>& str_lines, ofstream& fout) {
    logger.log("Matrix::writeLine");

    string str = "";
    for (auto &x : str_lines) {
        long long int j = 0;
        while (j < x.size() - 1) {
            fout << x[j] << ",";
            j++;
        }
        str = "";
        fout << x.back() << endl;
    }
    
}

void Matrix::makePermanent() {
    logger.log("Matrix::makePermanent");

    ofstream fout(this->sourceFileName, ios::trunc);

    int extra = (this->blockCount * SUBMATRIX_DIM - this->dimension);
    int colSize = this->dimension;
    vector<vector<int>> currPage;
    for (int rowIndex = 0; rowIndex < this->blockCount - 1; rowIndex++)
    {
        vector<vector<int>> vec2d (SUBMATRIX_DIM);
        for (int colIndex = 0; colIndex < this->blockCount - 1; colIndex++)
        {
            // cout << "getting page  " << rowIndex << ", " << colIndex << endl;
            currPage = bufferManager.getMatrixPage(this->matrixName, rowIndex, colIndex).getMatrix();
            for(int k = 0; k < SUBMATRIX_DIM; k++) {
                vec2d[k].insert(vec2d[k].end(), currPage[k].begin(), currPage[k].end());
                // cout << "writing row no " << k << " no of columns to write " << currPage[k].size() << endl; 
            }
        }

        currPage = bufferManager.getMatrixPage(this->matrixName, rowIndex, this->blockCount - 1).getMatrix();
        
        for(int k = 0; k < SUBMATRIX_DIM; k++) {
            // cout << "writing row no " << k << " no of columns to write " << (SUBMATRIX_DIM - extra) << endl; 
            vec2d[k].insert(vec2d[k].end(), currPage[k].begin(), currPage[k].end() - extra);
        }
        this->writeLine(vec2d, fout);
    }

    vector<vector<int>> lastBlockRow (SUBMATRIX_DIM - extra);
    for (int colIndex = 0; colIndex < this->blockCount - 1; colIndex++)
    {
        currPage = bufferManager.getMatrixPage(this->matrixName, this->blockCount-1, colIndex).getMatrix();
        for(int k = 0; k < SUBMATRIX_DIM - extra; k++) {
            // cout << "writing row no " << k << " no of columns to write " << currPage[k].size() << endl; 
            lastBlockRow[k].insert(lastBlockRow[k].end(), currPage[k].begin(), currPage[k].end());
        }
    }

    currPage = bufferManager.getMatrixPage(this->matrixName, this->blockCount-1, this->blockCount - 1).getMatrix();
    
    for(int k = 0; k < SUBMATRIX_DIM - extra; k++) {
        // cout << "writing row no " << k << " no of columns to write " << (SUBMATRIX_DIM - extra) << endl; 
        lastBlockRow[k].insert(lastBlockRow[k].end(), currPage[k].begin(), currPage[k].end() - extra);
    }
    this->writeLine(lastBlockRow, fout);

    fout.close();
}

void Matrix::print(int blockCount, int dimension) {
    logger.log("Matrix::print");

    // int numOfBlockRow = 0;
    // if(SUBMATRIX_DIM > 20) {
    //     numOfBlockRow = 1;
    // } else {
    //     numOfBlockRow = (20 / SUBMATRIX_DIM);
    //     if(20 % SUBMATRIX_DIM != 0)
    //         numOfBlockRow++;
    // }

    // //cout << "not of blocks in one column " << blockCount << endl;
    // int rowToPrint = 0;
    // for(int i = 0; i < numOfBlockRow; i++) {
    //     rowToPrint = 0;
    //     while(rowToPrint < SUBMATRIX_DIM) {
    //         for(int j = 0; j < blockCount; j++) {
    //             MatrixPage currPage = bufferManager.getMatrixPage(this->matrixName, i, j);
    //             vector<vector<int>> currPageMatrix = currPage.getMatrix();
                
    //             //cout << "size of curr  page matrix = " << currPageMatrix[0].size() << endl;
                
    //             for(int k = 0; k < SUBMATRIX_DIM; k++) {
    //                 cout << currPageMatrix[rowToPrint][k] << ", ";   
    //             }
    //         }

    //         cout << endl;

    //         rowToPrint++;
    //     }
    // }


    // cout << "dimension: " << dimension << endl;

    // cout << "maximum printable rows: " << 20 << endl;

    int effective_no_of_rows = min(dimension, 20);

    // cout << "effective_no_of_rows: " << effective_no_of_rows << endl;

    // cout << "SUBMATRIX_DIM: " << SUBMATRIX_DIM << endl;

    int numOfBlockRow = ceil((floor)(effective_no_of_rows) / (floor)(SUBMATRIX_DIM));

    // cout << "numOfBlockRow: " << numOfBlockRow << endl;

    int rowCount = 0;
    int colCount = 0;

    for(int i = 0; i < numOfBlockRow; i++) {
        bool row_flag = true;
        int rowToPrint = 0;
        while(rowToPrint < SUBMATRIX_DIM) {
            colCount = 0;
            for(int j = 0; j < blockCount; j++) {
                bool col_flag = true;
                MatrixPage currPage = bufferManager.getMatrixPage(this->matrixName, i, j);
                vector<vector<int>> currPageMatrix = currPage.getMatrix();
                
                //cout << "size of curr  page matrix = " << currPageMatrix[0].size() << endl;
                
                for(int k = 0; k < SUBMATRIX_DIM; k++) {
                    if(colCount == 0) {
                        cout << currPageMatrix[rowToPrint][k];
                    } else {
                        cout << ", " << currPageMatrix[rowToPrint][k];   
                    }
                    colCount++;
                    if(colCount == effective_no_of_rows)
                    {
                        col_flag = false;
                        break;
                    }
                }
                if(col_flag == false) {
                    break;
                }
            }

            cout << endl;
            rowToPrint++;
            rowCount++;
            // cout << "rowCount: " << rowCount << endl;
            if(rowCount == effective_no_of_rows)
            {
                row_flag = false;
                break;
            }
        }
        if(row_flag == false)
        {
            break;
        }
    }
}