#include "global.h"
// #include "sparseMatrix.h"

const string WHITESPACE = " \n\r\t\f\v";

string lltrim(const string &s)
{
    size_t start = s.find_first_not_of(WHITESPACE);
    return (start == std::string::npos) ? "" : s.substr(start);
}
 
string rrtrim(const string &s)
{
    size_t end = s.find_last_not_of(WHITESPACE);
    return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}

string ttrim(const string &s) 
{
    return rrtrim(lltrim(s));
}

SparseMatrix::SparseMatrix(const string& matrixName)
{
    logger.log("Matrix::Matrix");
    this->sourceFileName = "../data/" + matrixName + ".csv";
    this->matrixName = matrixName;
}

bool SparseMatrix::load() 
{
	logger.log("Sparse Matrix::load");
	fstream fin(this->sourceFileName, ios::in);
	string line;
	if(this->blockify(this->matrixName))
		return true;

	return false;
}

vector<int> get_1d_vec_from_line(string line)
{
    vector<int> tokens;
    stringstream ss(line);
    string temp;
    while(getline(ss, temp, ','))
    {
        string trimmed = ttrim(temp);
        tokens.push_back(stoi(trimmed));
    }

    return tokens;
}

bool SparseMatrix::blockify(string matrixName)
{
	ifstream fin(this->sourceFileName, ios::in);

	if (fin.peek() == ifstream::traits_type::eof()) 
	{
        cout << "BAD REQUEST: File is empty." << endl;
        return false;
    }

    string line;
    getline(fin, line);
    this->setConfig(line);

    fin.close();

    vector<vector<int>> vec2d (SPARSEMATRIX_DIM, vector<int> (3, -1)); // (3 cols, row, col, value)

    ifstream fin2(this->sourceFileName, ios::in);

    int total_non_zero_values = 0;
    int row_counter = 0;

    while (getline(fin2, line))
    {
        // cout << line << endl;
        vector<int> vec1d = get_1d_vec_from_line(line);
        for(int i=0; i<vec1d.size(); i++)
        {
            if(vec1d[i] != 0)
            {
                if(row_counter == SPARSEMATRIX_DIM)
                {
                    // for(auto it: vec2d)
                    // {
                    //     for(auto it2: it)
                    //     {
                    //         cout << it2 << " ";
                    //     }
                    //     cout << endl;
                    // }
                    bufferManager.writeSparseMatrixPage(this->matrixName, ((total_non_zero_values/SPARSEMATRIX_DIM))-1, vec2d);
                    row_counter = 0;
                    vec2d.assign(SPARSEMATRIX_DIM, vector<int> (3, -1));
                }
                total_non_zero_values++;
                vector<int> temp(3);
                temp[0] = row_counter;
                temp[1] = i;
                temp[2] = vec1d[i];
                vec2d[row_counter] = temp;
                row_counter++;
            }
        }
    }

    cout << endl << "total non-zero values: " << total_non_zero_values << endl;

    this->total_non_zero_values = total_non_zero_values;

    bufferManager.writeSparseMatrixPage(this->matrixName, total_non_zero_values/SPARSEMATRIX_DIM, vec2d);

    this->blockCount = ceil((double)(total_non_zero_values) / (double)(SPARSEMATRIX_DIM));

    fin2.close();

    return true;
}

void SparseMatrix::setConfig(const string& line)
{
	logger.log("Sparse Matrix::setConfig");
	int count = 0;
    int x = 0;
    for (auto& c: line) {
        if (c == ',') {
            count++;
        }
        else {
            x++;
        }
    }
    x = x%SUBMATRIX_DIM;
    if (line.back() != ',') {
        x++;
        count++;
    }
    this->dimension = count;
    count = dimension;
    // this->blockCount = ceil((double)(this->dimension)/(double)(SPARSEMATRIX_DIM));
}

void SparseMatrix::sparse_transpose()
{
    for(int i=0; i<this->blockCount ; i++)
    {
        SparseMatrixPage current_page = bufferManager.getSparseMatrixPage(this->matrixName, i);
        vector<vector<int>> current_matrix = current_page.getMatrix();
        // cout << "vector at page no. " << i << endl;
        // for(auto it: current_matrix)
        // {
        //     for(auto it2: it)
        //     {
        //         cout << it2 << " ";
        //     }
        //     cout << endl;
        // }

        for(int i=0; i<current_matrix.size(); i++)
        {
            swap(current_matrix[i][0], current_matrix[i][1]); // swapping row, col
        }   

        bufferManager.writeSparseMatrixPage(this->matrixName, i, current_matrix);
    }
}

void SparseMatrix::print(int blockCount, int dimension )
{
    string page_name = bufferManager.getSparseMatrixPageName(this->matrixName, 0);
    vector<vector<int>> vec0 = bufferManager.readSparseMatrixPageFromTemp(page_name);
    int effective_no_of_rows = min(total_non_zero_values, 20);
    cout << "Row" << "\t" << "Col" << "\t" << "Val" << endl;
    for(int i=0; i<effective_no_of_rows; i++)
    {
        cout << vec0[i][0] << "\t" << vec0[i][1] << "\t" << vec0[i][2] << endl;
    }
} 

