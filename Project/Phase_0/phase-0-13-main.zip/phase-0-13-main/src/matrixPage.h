class MatrixPage {

    int pageRowIndex;
    vector<vector<int>> matrix;
    int pageColIndex;
    string pageName;
    string matrixName;

   public:
    MatrixPage(const string& matrixName, int pageRowIndex, int pageColIndex);
    vector<vector<int>> getMatrix();
    MatrixPage(){};
    string getMatrixDetails();
    string getPageName();
    void setMatrix(vector<vector<int>> matrix);
    MatrixPage(const string& matrixName, int pageRowIndex, int pageColIndex, vector<vector<int>>& data);
    string getMatrixPageName(string matrixName, int pageRowIndex, int pageColIndex);
    void writeMatrixPage();
    void generateMatrixFromTemp();
};