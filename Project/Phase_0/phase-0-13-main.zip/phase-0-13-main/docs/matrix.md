# Matrix implementation details

## Part 2: `Page Layout`
We are given an input of **N*N(N ≤ 10^5)** matrix. We have splitted this large matrix into smaller **M*M** matrices, so that each **M*M** matrix can fit in a block. The block size is predefined as **8 KB**. So, if each matrix of size **M*M** needs to fit in a block, the value of M should be equal to `(int)sqrt((BLOCK_SIZE * 1024) / sizeof(int))`. Therefore **M=45** in this case. So, each block will contain matrix of size **45*45**. Therefore, the large **N*N** matrix is splitted into smaller **45*45** matrices and they are stored in a page.

This storage method was chosen primarily for its effectiveness in transposing. Transpose wouldn't have worked well with row-wise spanning across pages because it would have required many more page accesses.

Now, every **45*45** block is written into a page. The name of a page is given like this. Page name = Matrix_Name + Row of Block + Col of Block. For example, if we are given a **50*50** matrix, then we need total 4 pages to store the matrix. If the name of the matrix is M1, then the page names will be M1_0_0, M1_0_1, M1_1_0, M1_1_1.

For example, we are given with a `5*5` matrix:

                         4 5 6 7 8
                         1 2 3 4 5
                         3 5 7 8 2
                         4 5 9 0 2
                         1 5 4 3 8 


Now, let's assume our block size is `3*3`. Then The page layout will be:

     4  5  6       7  8 -1       4  5  9     0  2  -1
     1  2  3       4  5 -1       1  5  4     3  8  -1
     3  5  7       8  2 -1      -1 -1 -1    -1 -1  -1
    
     Page_0_0      Page_0_1      Page_1_0    Page_1_1
       

The Paging is done by `LOAD MATRIX` command.

**Syntax: LOAD MATRIX `MATRIX_NAME`** \
The command LOAD MATRIX invokes the **loadMatrix** executor, which then instantiates the Matrix class and invokes its **constructor**. Following instantiation, **matrix.load()** is called, which in turn calls **matrix.blockify()**. The **blockify()** function is in charge of reading the matrix, splitting it into smaller 45*45 matrices, and writing these matrices to pages by calling **bufferManager.writeMatrixPage()**, which then calls **bufferManager.pushMatrixPageIntoPool()** and **bufferManager.writeMatrixPageIntoTemp()**. \
**bufferManager.pushMatrixPageIntoPool()** is responsible for writing the page into a unordred_map<std::string, MatrixPage>. The map keeps track of a mtrixPage corresponding to it's page name.
**bufferManager.writeMatrixPageIntoTemp()** is responsible for writing the page in the secondary memory i.e. the temp folder inside data folder.

The **blockify()** function works as follows:

 - It calls **setConfig(firstLineOfMatrix)**, which calculates the dimensions of the input matrix and determines the number of blocks required, calculated as `blockCount = ceil((double)(this->dimension)/(double)(SUBMATRIX_DIM))`. Here *SUBMATRIX_DIM = 45*.
 - Now, the idea is go line by line. For each line process the line and store the integers in that line into a 1d vector of `length = max(dimension, ceil(dimension/SUBMATRIX_DIM)*SUBMATRIX_DIM) of the matrix`. If the dimension of the 1d vec is smaller than length, pad with -1. Keep on adding these 1d vectors in a 2d vector of size **SUBMATRIX_DIM*dimesnion_of_the_matrix**. ALso, initialize the 2d vector with -1 at the beginning. Keep a row_counter. When the *row_counter == SUBMATRIX_DIM* then we have a complete block of size **SUBMATRIX_DIM*dimesnion_of_the_matrix**. Then, we split the big block into sub_blocks of size **SUBMATRIX_DIM*SUBMATRIX_DIM** and write them into proper page. Also, reset the row_counter to 0.

 - For calculation of the page number, we use this formula. \
 `page_row = ceil((float)line_counter/(float)SUBMATRIX_DIM) - 1` \
 `page_col = i/SUBMATRIX_DIM` \
 `line_counter` is the indiactor of the line number in the csv file. \
 `i` runs from `0` to the `dimesnion_of_the_matrix`.
 - **Note**: As the NxN matrix may not perfectly fit into 45x45 matrices, the remaining space in 45x45 matrices is padded with -1s, as the input matrix only contains positive integers

## Part 2: `CROSS_TRANSPOSE`
**Syntax: CROSS_TRANSPOSE `MATRIX_NAME_1` `MATRIX_NAME_2`** \
The CROSS_TRANSPOSE command invokes the **executeCROSSTRANSPOSE** executor, which searches matrixCatalogue for a matrix with the given name and calls the **matrix.cross_transpose()** function.

The **cross_transpose()** function works as follows:

 - Loop **rowIndex** from 0 to blockCount, loop **colIndex** from 0 to blockCount (**nested** loops). In each inner iteration:
	 -  Get the **(rowIndex, colIndex)** page of 1st matrix say page1 and **(colIndex, rowIndex)** page of 2nd matrix say page2
	 - Retrieve the matrices from each of these pages. Let's call them matrix1 and matrix2
     - **Now, matrix1's transpose needs to be placed in matrix2 and matrix2's transpose needs to be placed in matrix1 by the help of loop**
     - Now, write the matrix1(which is now holding the transpose of matrix2) in page1 and matrix2(which is now holding the transpose of matrix1) in page2
 - So, basically we are using two temporary matrices of size 45*45 to hold matrix1 and matrix2 and performing cross transpose between them. So, the extra memory used is constant here.

 For example, if the `matrix1` is:

                         4 5 6 7
                         1 2 3 4
                         3 5 7 8
                         4 5 9 0

Now, let's assume our block size is `2*2`. Then The page layout will be:

     4  5           6  7           3  5      7  8
     1  2           3  4           4  5      9  0
    
     Page_0_0      Page_0_1      Page_1_0    Page_1_1

For example, if the `matrix2` is:

                         9 0 2 3
                         2 8 8 4
                         6 5 5 4
                         2 8 4 4


Now, let's assume our block size is `2*2`. Then The page layout will be:

      9  0           2  3           6  5      5  4
      2  8           8  4           2  8      4  4
    
    Page_0_0      Page_0_1      Page_1_0    Page_1_1

After `CROSS_TRANSPOSE` the blocks will be:

      9  2           6  2          2  8        5  4
      0  8           5  8          3  4        4  4
      
     m1  Page_0_0   Page_0_1      Page_1_0    Page_1_1

      4  1           3  4          6  3        7  9
      5  2           5  5          7  4        8  0

     m2  Page_0_0    Page_0_1     Page_1_0    Page_1_1

 Finally `matrix1` and `matrix2` will be:

               9 2 6 2             4 1 3 4
               0 8 5 8             5 2 5 5
               2 8 5 4             6 3 7 9
               3 4 4 4             7 4 8 0
               matrix1             matrix2
       


## Part 3: `Discussion about sparse matrix`
Let's say we are given a **N*N** matrix. 
### Storage Mechanism: 
We will maintain a table of K*3 where only the non-zero values of the matrix will be stored. So, it will have 3 columns. They are row of the original matrix, col of the original matrix and the non-zero value. Now, we know that each page is of size 8 KB. So, K = ceil(Page Size / Size of int * 3). Here, after calculation K = 667. So, we will be able to store 667 such rows in a single page. So, if a matrix has 669 non-zero values, it will require two pages to store the content. In the second page, the blank entries will be filled by -1. eg.(row=-1, col=-1, value=-1). \
We will also store the dimension of the matrix to get back the matrix in original form.\
For eg. if a matrix is of size `4*4` and the matrix is as follows:

               1 0 0 9
               0 4 0 6
               0 8 0 0
               3 0 0 0

Then the sparse representation will be as follows:

               row col value
                0   0    1
                0   3    9
                1   1    4
                1   3    6
                3   1    8
                4   0    3

For a moment let's say, we can only accomodate 4 rows in a single page. So, in that case, the representation will be:

               Page1:
               0    0    1
               0    3    9
               1    1    4
               1    3    6

               Page2:
               3    1    8
               4    0    3
               -1   -1   -1
               -1   -1   -1



### Transpose:
For transpose operation, we need to just fetch each page, then go through each triplet (row, col, value) and swap the row and col. So, if the entry was (1, 2, 3) after transpose it would be (2, 1, 3). 

If we transpose the above matrix then the content will be as follows:

               Page 1:
               0    0    1
               3    0    9
               1    1    4
               3    1    6

               Page 2:
               1    3    8
               0    4    3
               -1   -1   -1
               -1   -1   -1

We have implemented it in codebase also:

LOAD SPARSE MATRIX `MATRIX_NAME`\
TRANSPOSE SPARSE ` MATRIX_NAME` \
PRINT SPARSE MATRIX `MATRIX_NAME` 