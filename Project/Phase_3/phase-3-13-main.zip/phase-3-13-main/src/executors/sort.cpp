#include"global.h"
/**
 * @brief File contains method to process SORT commands.
 * 
 * syntax:
 * R <- SORT relation_name BY column_name IN sorting_order
 * sorting_order = ASC | DESC 
 * 
 * <new_table_name> <- SORT <table_name> BY <column_name> IN ASC | DESC
 * <new_table_name> <- SORT <table_name> BY <column_name> IN ASC | DESC BUFFER <buffer_size>
 * 
 * LOAD B
 * B1 <- SORT B BY B IN ASC
 * B2 <- SORT B BY B IN DESC
 * B3 <- SORT B BY B IN ASC BUFFER 4
 * B4 <- SORT B BY B IN DESC BUFFER 4
 * B5 <- SORT B BY B IN ASC BUFFER 3
 * B6 <- SORT B BY B IN DESC BUFFER 3
 * 
 * LOAD C
 * C1 <- SORT C BY B IN ASC
 * C2 <- SORT C BY B IN DESC
 * C3 <- SORT C BY B IN ASC BUFFER 4
 * C4 <- SORT C BY B IN DESC BUFFER 4
 * C5 <- SORT C BY B IN ASC BUFFER 3
 * C6 <- SORT C BY B IN DESC BUFFER 3
 * 
 * LOAD D
 * D1 <- SORT D BY B IN ASC
 * D2 <- SORT D BY B IN DESC
 * D3 <- SORT D BY B IN ASC BUFFER 4
 * D4 <- SORT D BY B IN DESC BUFFER 4
 * D5 <- SORT D BY B IN ASC BUFFER 3
 * D6 <- SORT D BY B IN DESC BUFFER 3
 * 
 * LOAD E
 * E1 <- SORT E BY B IN ASC
 * E2 <- SORT E BY B IN DESC
 * E3 <- SORT E BY B IN ASC BUFFER 4
 * E4 <- SORT E BY B IN DESC BUFFER 4
 * E5 <- SORT E BY B IN ASC BUFFER 3
 * E6 <- SORT E BY B IN DESC BUFFER 3
 * 
 * LOAD F
 * F1 <- SORT F BY B IN ASC
 * F2 <- SORT F BY B IN DESC
 * F3 <- SORT F BY B IN ASC BUFFER 4
 * F4 <- SORT F BY B IN DESC BUFFER 4
 * F5 <- SORT F BY B IN ASC BUFFER 3
 * F6 <- SORT F BY B IN DESC BUFFER 3
 * 
 * LOAD G
 * G1 <- SORT G BY B IN ASC
 * G2 <- SORT G BY B IN DESC
 * G3 <- SORT G BY B IN ASC BUFFER 4
 * G4 <- SORT G BY B IN DESC BUFFER 4
 * G5 <- SORT G BY B IN ASC BUFFER 3
 * G6 <- SORT G BY B IN DESC BUFFER 3
 * 
 */
bool syntacticParseSORT(){
    logger.log("syntacticParseSORT");
    // if(tokenizedQuery.size()!= 8 || tokenizedQuery[4] != "BY" || tokenizedQuery[6] != "IN"){
    //     cout<<"SYNTAX ERROR"<<endl;
    //     return false;
    // }
    if(tokenizedQuery.size() == 8) // B1 <- SORT B BY B IN ASC
    {
        if(tokenizedQuery[4] != "BY" || tokenizedQuery[6] != "IN" || !(tokenizedQuery[7] == "ASC" || tokenizedQuery[7] == "DESC"))
        {
            cout<<"SYNTAX ERROR"<<endl;
            return false;
        }
    }
    else if(tokenizedQuery.size() == 10) // B2 <- SORT B BY b IN ASC BUFFER 4
    {
        if(tokenizedQuery[4] != "BY" || tokenizedQuery[6] != "IN" || !(tokenizedQuery[7] == "ASC" || tokenizedQuery[7] == "DESC") || tokenizedQuery[8] != "BUFFER")
        {
            cout<<"SYNTAX ERROR"<<endl;
            return false;
        }
    }
    else
    {
        cout<<"SYNTAX ERROR"<<endl;
        return false;
    }
    
    parsedQuery.queryType = SORT;
    parsedQuery.sortResultRelationName = tokenizedQuery[0];
    parsedQuery.sortRelationName = tokenizedQuery[3];
    parsedQuery.sortColumnName = tokenizedQuery[5];
    string sortingStrategy = tokenizedQuery[7];
    if(sortingStrategy == "ASC")
        parsedQuery.sortingStrategy = ASC;
    else if(sortingStrategy == "DESC")
        parsedQuery.sortingStrategy = DESC;
    else{
        cout<<"SYNTAX ERROR"<<endl;
        return false;
    }

    if(tokenizedQuery.size() == 10)
    {
        parsedQuery.sortBufferSize = stoi(tokenizedQuery[9]);
    }
    else if(tokenizedQuery.size() == 8)
    {
        parsedQuery.sortBufferSize = DEFAULT_BUFFER_SIZE;
    }

    return true;
}

bool semanticParseSORT(){
    logger.log("semanticParseSORT");

    if(tableCatalogue.isTable(parsedQuery.sortResultRelationName)){
        cout<<"SEMANTIC ERROR: Resultant relation already exists"<<endl;
        return false;
    }

    if(!tableCatalogue.isTable(parsedQuery.sortRelationName)){
        cout<<"SEMANTIC ERROR: Relation doesn't exist"<<endl;
        return false;
    }

    if(!tableCatalogue.isColumnFromTable(parsedQuery.sortColumnName, parsedQuery.sortRelationName)){
        cout<<"SEMANTIC ERROR: Column doesn't exist in relation"<<endl;
        return false;
    }

    return true;
}

void executeSORT(){
    logger.log("executeSORT");
    cout << "Executing SORT" << endl;

    Table table = *tableCatalogue.getTable(parsedQuery.sortRelationName);
    vector<string> oldTableColumns =  table.columns;
    Table* resultantTable = new Table(parsedQuery.sortResultRelationName, oldTableColumns);

    Cursor cursor = table.getCursor();
    vector<int> row = cursor.getNext();

    while (row.empty() == false)
    {
        resultantTable->writeRow<int>(row);
        row = cursor.getNext();
    }
    
    resultantTable->blockify();
    tableCatalogue.insertTable(resultantTable);

    // cout << "table exists: " << tableCatalogue.isTable(parsedQuery.sortResultRelationName) << endl;
    // cout << "Buffer Size: " << parsedQuery.sortBufferSize << endl;
    
    if(resultantTable->sortTable(parsedQuery.sortingStrategy, parsedQuery.sortColumnName, parsedQuery.sortBufferSize) == true) 
    {
        cout << "****************** SORTING SUCCESSFUL ******************" << endl;
        logger.log("SORTING SUCCESSFUL");
    }
    else
    {
        cout << "xxxxxxxxxxxxxxxxxx ERROR IN SORTING xxxxxxxxxxxxxxxxxx" << endl;
        logger.log("ERROR IN SORTING");
    }

    return;
}