#include "global.h"
/**
 * @brief 
 * SYNTAX: LOAD relation_name
 * UPDATE <table_name> COLUMN <column_name> <OPERATOR> <value>
 * UPDATE EMPLOYEE COLUMN Ssn MULTIPLY 5
 * Expected Behaviour of this command is each value in the column “Ssn” in the 
 * “EMPLOYEE” Table will be multiplied by the value 5
 * <OPERATOR> can take values MULTIPLY, ADD, SUBTRACT
 * 
 * UPDATE U COLUMN B ADD 5 
 * UPDATE U COLUMN B SUBTRACT 5 
 * UPDATE U COLUMN B MULTIPLY 5 
 * 
 * UPDATE U COLUMN B ADD 5 CONCURRENT_PROCESS 3 WITH_LOCK
 * UPDATE U COLUMN B SUBTRACT 5 CONCURRENT_PROCESS 3 WITH_LOCK
 * UPDATE U COLUMN B MULTIPLY 5 CONCURRENT_PROCESS 3 WITH_LOCK
 * 
 * UPDATE U COLUMN B ADD 5 CONCURRENT_PROCESS 3 WITHOUT_LOCK
 * UPDATE U COLUMN B SUBTRACT 5 CONCURRENT_PROCESS 3 WITHOUT_LOCK
 * UPDATE U COLUMN B MULTIPLY 5 CONCURRENT_PROCESS 3 WITHOUT_LOCK
 * 
 * LOAD UU
 * UPDATE UU COLUMN B ADD 5 CONCURRENT_PROCESS 3 WITH_LOCK
 * UPDATE UU COLUMN B SUBTRACT 5 CONCURRENT_PROCESS 3 WITH_LOCK
 * UPDATE UU COLUMN B MULTIPLY 5 CONCURRENT_PROCESS 3 WITH_LOCK
 * 
 * LOAD UU
 * UPDATE UU COLUMN B ADD 5 CONCURRENT_PROCESS 3 WITHOUT_LOCK
 * UPDATE UU COLUMN B SUBTRACT 5 CONCURRENT_PROCESS 3 WITHOUT_LOCK
 * UPDATE UU COLUMN B MULTIPLY 5 CONCURRENT_PROCESS 3 WITHOUT_LOCK
 * 
 * 
 * COMMAND TO RUN FOR DEMO (SEE HOW UPDATES ARE LOST IN LAST COMMAND WITHOUT_LOCK)
 * LOAD UU
 * PRINT UU
 * UPDATE UU COLUMN B ADD 5 CONCURRENT_PROCESS 3 WITH_LOCK
 * PRINT UU
 * UPDATE UU COLUMN B ADD 5 CONCURRENT_PROCESS 3 WITHOUT_LOCK
 * PRINT UU
 */
bool syntacticParseUPDATE()
{
    logger.log("syntacticParseUPDATE");
    if (tokenizedQuery.size() == 6)
    {
        if(!((tokenizedQuery[0] == "UPDATE" && tokenizedQuery[2] == "COLUMN") && 
        (tokenizedQuery[4] == "MULTIPLY" || tokenizedQuery[4] == "ADD") || tokenizedQuery[4] == "SUBTRACT"))
        {
            cout << "SYNTAX ERROR" << endl;
            return false;
        }
    }
    else if (tokenizedQuery.size() == 9)
    {
        if(!((tokenizedQuery[0] == "UPDATE" && tokenizedQuery[2] == "COLUMN") && 
        (tokenizedQuery[4] == "MULTIPLY" || tokenizedQuery[4] == "ADD") || tokenizedQuery[4] == "SUBTRACT") && (tokenizedQuery[6] != "CONCURRENT_PROCESS") && (tokenizedQuery[7] == "WITH_LOCK" || tokenizedQuery[7] == "WITHOUT_LOCK"))
        {
            cout << "SYNTAX ERROR" << endl;
            return false;
        }
    }
    else
    {
        cout << "SYNTAX ERROR" << endl;
        return false;
    }
    parsedQuery.queryType = UPDATE;
    parsedQuery.loadRelationName = tokenizedQuery[1];
    parsedQuery.updateColumnName = tokenizedQuery[3];

    for(int i=0; i<tokenizedQuery[5].size(); i++)
    {
        if(!isdigit(tokenizedQuery[5][i]))
        {
            cout << "SYNTAX ERROR" << endl;
            return false;
        }
    }

    parsedQuery.operand = stoi(tokenizedQuery[5]);

    string operationType = tokenizedQuery[4];
    if(operationType == "MULTIPLY")
        parsedQuery.operationType = MULTIPLY;
    else if(operationType == "ADD")
        parsedQuery.operationType = ADD;
    else if(operationType == "SUBTRACT")
        parsedQuery.operationType = SUBTRACT;
    else{
        cout<<"SYNTAX ERROR"<<endl;
        return false;
    }

    if (tokenizedQuery.size() == 9)
    {
        parsedQuery.updateNoOfConcurrentProcesses = stoi(tokenizedQuery[7]);
        if(tokenizedQuery[8] == "WITH_LOCK")
        {
            parsedQuery.updateLock = true;
        }
        else if(tokenizedQuery[8] == "WITHOUT_LOCK")
        {
            parsedQuery.updateLock = false;
        }
    }

    return true;
}

bool semanticParseUPDATE()
{
    logger.log("semanticParseUPDATE");
    if (!tableCatalogue.isTable(parsedQuery.loadRelationName))
    {
        cout << "SEMANTIC ERROR: Relation doesn't exist" << endl;
        return false;
    }

    if(!tableCatalogue.isColumnFromTable(parsedQuery.updateColumnName, parsedQuery.loadRelationName)){
        cout<<"SEMANTIC ERROR: Column doesn't exist in relation"<<endl;
        return false;
    }
    return true;
}

void executeUPDATE()
{
    cout << "Inside executeUPDATE" << endl;
    logger.log("executeUPDATE");

    Table* table = tableCatalogue.getTable(parsedQuery.loadRelationName);

    if(parsedQuery.updateNoOfConcurrentProcesses == 1)
    {
        if(table->updateTable(parsedQuery.updateColumnName, parsedQuery.operationType, parsedQuery.operand) == true) 
        {
            cout << "****************** UPDATE SUCCESSFUL ******************" << endl;
            logger.log("UPDATE SUCCESSFUL");
        }
        else
        {
            cout << "xxxxxxxxxxxxxxxxxx ERROR IN UPDATE xxxxxxxxxxxxxxxxxx" << endl;
            logger.log("ERROR IN UPDATE");
        }
    }
    else
    {
        if(table->updateTableSimultaneously(parsedQuery.updateColumnName, parsedQuery.operationType, parsedQuery.operand, parsedQuery.updateNoOfConcurrentProcesses, parsedQuery.updateLock) == true) 
        {
            cout << "****************** Simultaneous UPDATE SUCCESSFUL ******************" << endl;
            logger.log("Simultaneous UPDATE SUCCESSFUL");
        }
        else
        {
            cout << "xxxxxxxxxxxxxxxxxx ERROR IN UPDATE xxxxxxxxxxxxxxxxxx" << endl;
            logger.log("ERROR IN Simultaneous UPDATE");
        }
    }

    return;
}