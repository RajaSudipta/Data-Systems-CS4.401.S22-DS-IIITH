#include "global.h"
#include <thread>
#include <mutex>
#include <future>
#include <fcntl.h>
#include <unistd.h>
using namespace std;

std::mutex m;

/**
 * @brief Construct a new Table:: Table object
 *
 */
Table::Table()
{
    logger.log("Table::Table");
}

/**
 * @brief Construct a new Table:: Table object used in the case where the data
 * file is available and LOAD command has been called. This command should be
 * followed by calling the load function;
 *UPDATE UU COLUMN B ADD 5 CONCURRENT_PROCESS 3 WITHOUT_LOCK
 * @param tableName 
 */
Table::Table(string tableName)
{
    logger.log("Table::Table");
    this->sourceFileName = "../data/" + tableName + ".csv";
    this->tableName = tableName;
}

/**
 * @brief Construct a new Table:: Table object used when an assignment command
 * is encountered. To create the table object both the table name and the
 * columns the table holds should be specified.
 *
 * @param tableName 
 * @param columns 
 */
Table::Table(string tableName, vector<string> columns)
{
    logger.log("Table::Table");
    this->sourceFileName = "../data/temp/" + tableName + ".csv";
    this->tableName = tableName;
    this->columns = columns;
    this->columnCount = columns.size();
    this->maxRowsPerBlock = (uint)((BLOCK_SIZE * 1000) / (sizeof(int) * columnCount));
    this->writeRow<string>(columns);
}

/**
 * @brief The load function is used when the LOAD command is encountered. It
 * reads data from the source file, splits it into blocks and updates table
 * statistics.
 *
 * @return true if the table has been successfully loaded 
 * @return false if an error occurred 
 */
bool Table::load()
{
    logger.log("Table::load");
    fstream fin(this->sourceFileName, ios::in);
    string line;
    if (getline(fin, line))
    {
        fin.close();
        if (this->extractColumnNames(line))
            if (this->blockify())
                return true;
    }
    fin.close();
    return false;
}

/**
 * @brief Function extracts column names from the header line of the .csv data
 * file. 
 *
 * @param line 
 * @return true if column names successfully extracted (i.e. no column name
 * repeats)
 * @return false otherwise
 */
bool Table::extractColumnNames(string firstLine)
{
    logger.log("Table::extractColumnNames");
    unordered_set<string> columnNames;
    string word;
    stringstream s(firstLine);
    while (getline(s, word, ','))
    {
        word.erase(std::remove_if(word.begin(), word.end(), ::isspace), word.end());
        if (columnNames.count(word))
            return false;
        columnNames.insert(word);
        this->columns.emplace_back(word);
    }
    this->columnCount = this->columns.size();
    this->maxRowsPerBlock = (uint)((BLOCK_SIZE * 1000) / (sizeof(int) * this->columnCount));
    return true;
}

/**
 * @brief This function splits all the rows and stores them in multiple files of
 * one block size. 
 *
 * @return true if successfully blockified
 * @return false otherwise
 */
bool Table::blockify()
{
    logger.log("Table::blockify");
    ifstream fin(this->sourceFileName, ios::in);
    string line, word;
    vector<int> row(this->columnCount, 0);
    vector<vector<int>> rowsInPage(this->maxRowsPerBlock, row);
    int pageCounter = 0;
    unordered_set<int> dummy;
    dummy.clear();
    this->distinctValuesInColumns.assign(this->columnCount, dummy);
    this->distinctValuesPerColumnCount.assign(this->columnCount, 0);
    getline(fin, line);
    while (getline(fin, line))
    {
        stringstream s(line);
        for (int columnCounter = 0; columnCounter < this->columnCount; columnCounter++)
        {
            if (!getline(s, word, ','))
                return false;
            row[columnCounter] = stoi(word);
            rowsInPage[pageCounter][columnCounter] = row[columnCounter];
        }
        pageCounter++;
        this->updateStatistics(row);
        if (pageCounter == this->maxRowsPerBlock)
        {
            bufferManager.writePage(this->tableName, this->blockCount, rowsInPage, pageCounter);
            this->blockCount++;
            this->rowsPerBlockCount.emplace_back(pageCounter);
            pageCounter = 0;
        }
    }
    if (pageCounter)
    {
        bufferManager.writePage(this->tableName, this->blockCount, rowsInPage, pageCounter);
        this->blockCount++;
        this->rowsPerBlockCount.emplace_back(pageCounter);
        pageCounter = 0;
    }

    if (this->rowCount == 0)
        return false;
    this->distinctValuesInColumns.clear();
    return true;
}

/**
 * @brief Given a row of values, this function will update the statistics it
 * stores i.e. it updates the number of rows that are present in the column and
 * the number of distinct values present in each column. These statistics are to
 * be used during optimisation.
 *
 * @param row 
 */
void Table::updateStatistics(vector<int> row)
{
    this->rowCount++;
    for (int columnCounter = 0; columnCounter < this->columnCount; columnCounter++)
    {
        if (!this->distinctValuesInColumns[columnCounter].count(row[columnCounter]))
        {
            this->distinctValuesInColumns[columnCounter].insert(row[columnCounter]);
            this->distinctValuesPerColumnCount[columnCounter]++;
        }
    }
}

/**
 * @brief Checks if the given column is present in this table.
 *
 * @param columnName 
 * @return true 
 * @return false 
 */
bool Table::isColumn(string columnName)
{
    logger.log("Table::isColumn");
    for (auto col : this->columns)
    {
        if (col == columnName)
        {
            return true;
        }
    }
    return false;
}

/**
 * @brief Renames the column indicated by fromColumnName to toColumnName. It is
 * assumed that checks such as the existence of fromColumnName and the non prior
 * existence of toColumnName are done.
 *
 * @param fromColumnName 
 * @param toColumnName 
 */
void Table::renameColumn(string fromColumnName, string toColumnName)
{
    logger.log("Table::renameColumn");
    for (int columnCounter = 0; columnCounter < this->columnCount; columnCounter++)
    {
        if (columns[columnCounter] == fromColumnName)
        {
            columns[columnCounter] = toColumnName;
            break;
        }
    }
    return;
}

/**
 * @brief Function prints the first few rows of the table. If the table contains
 * more rows than PRINT_COUNT, exactly PRINT_COUNT rows are printed, else all
 * the rows are printed.
 *
 */
void Table::print()
{
    logger.log("Table::print");
    uint count = min((long long)PRINT_COUNT, this->rowCount);

    //print headings
    this->writeRow(this->columns, cout);

    Cursor cursor(this->tableName, 0);
    vector<int> row;
    for (int rowCounter = 0; rowCounter < count; rowCounter++)
    {
        row = cursor.getNext();
        this->writeRow(row, cout);
    }
    printRowCount(this->rowCount);
}


/**
 * @brief This function returns one row of the table using the cursor object. It
 * returns an empty row is all rows have been read.
 *
 * @param cursor 
 * @return vector<int> 
 */
void Table::getNextPage(Cursor *cursor)
{
    logger.log("Table::getNext");

        if (cursor->pageIndex < this->blockCount - 1)
        {
            cursor->nextPage(cursor->pageIndex+1);
        }
}

/**
 * @brief called when EXPORT command is invoked to move source file to "data"
 * folder.
 *
 */
void Table::makePermanent()
{
    logger.log("Table::makePermanent");
    if(!this->isPermanent())
        bufferManager.deleteFile(this->sourceFileName);
    string newSourceFile = "../data/" + this->tableName + ".csv";
    ofstream fout(newSourceFile, ios::out);

    //print headings
    this->writeRow(this->columns, fout);

    Cursor cursor(this->tableName, 0);
    vector<int> row;
    for (int rowCounter = 0; rowCounter < this->rowCount; rowCounter++)
    {
        row = cursor.getNext();
        this->writeRow(row, fout);
    }
    fout.close();
}

/**
 * @brief Function to check if table is already exported
 *
 * @return true if exported
 * @return false otherwise
 */
bool Table::isPermanent()
{
    logger.log("Table::isPermanent");
    if (this->sourceFileName == "../data/" + this->tableName + ".csv")
    return true;
    return false;
}

/**
 * @brief The unload function removes the table from the database by deleting
 * all temporary files created as part of this table
 *
 */
void Table::unload(){
    logger.log("Table::~unload");
    for (int pageCounter = 0; pageCounter < this->blockCount; pageCounter++)
        bufferManager.deleteFile(this->tableName, pageCounter);
    if (!isPermanent())
        bufferManager.deleteFile(this->sourceFileName);
}

/**
 * @brief Function that returns a cursor that reads rows from this table
 * 
 * @return Cursor 
 */
Cursor Table::getCursor()
{
    logger.log("Table::getCursor");
    Cursor cursor(this->tableName, 0);
    return cursor;
}
/**
 * @brief Function that returns the index of column indicated by columnName
 * 
 * @param columnName 
 * @return int 
 */
int Table::getColumnIndex(string columnName)
{
    logger.log("Table::getColumnIndex");
    for (int columnCounter = 0; columnCounter < this->columnCount; columnCounter++)
    {
        if (this->columns[columnCounter] == columnName)
            return columnCounter;
    }
}

void Table::writePageForSort(int &writePageIndex, vector<vector<int>>& sortedRows, int &pageCounter)
{
    string tempPagename = this->tableName + "_temp";
    Page currPage = Page(tempPagename, writePageIndex, sortedRows, pageCounter);
    // Page currPage = Page(this->tableName, writePageIndex, sortedRows, pageCounter);
    writePageIndex++;
    currPage.writePage();
    pageCounter = 0;
}

bool Table::renameTempPagesForSort()
{
    int pageNum = 0;
    while(pageNum < this->blockCount) 
    {
        string oldPageName = "../data/temp/" + this->tableName + "_temp" + "_Page" + to_string(pageNum);
        string newPageName = "../data/temp/" + this->tableName + "_Page" + to_string(pageNum);

        int rename_res = rename(oldPageName.c_str(), newPageName.c_str());

        if(rename_res != 0) 
        {
            cout << "Error renaming file: " << oldPageName  << " -> " << newPageName << endl;
            return false;
        }
        // cout << "oldName: " << oldPageName << ", newName: " << newPageName << endl;
        // bufferManager.deleteFromPool(newName);
        pageNum++;
        bufferManager.deletePageFromPool(newPageName);
    }
    return true;
}

bool Table::sortTable(int sortType, string columnName, int sortBufferSize)
{
    cout << "Executing sortTable" << endl;
    logger.log("Table::sortTable");

    auto it = find(this->columns.begin(), this->columns.end(), columnName);
    if(it == this->columns.end())
    {
        return false;
    }

    int colIndex = it - this->columns.begin();

    // cout << "colIndex: " << colIndex << endl;

    int sortingMultiplicationFactor;

    if(sortType == 0) // ASC
    {
        sortingMultiplicationFactor = -1;
    }
    else if(sortType == 1) // DESC
    {
        sortingMultiplicationFactor = 1;
    }

    // cout << "sortingMultiplicationFactor: " << sortingMultiplicationFactor << endl;

    /* sort phase, sorting individual page */
    priority_queue< pair<int, int> > pq;  // (max heap)priority queue to perform merges (value of the column, row number of the corresponding page)
    
    for(int i = 0; i < this->blockCount; i++) 
    {
        // Page currPage = Page(this->tableName, i);
        Page currPage = bufferManager.getPage(this->tableName, i);
        vector<vector<int>> rowsOfCurrentPage = currPage.fetchRows();

        // cout << "Page " << i << ", size: " << rowsOfCurrentPage.size() << endl;

        int j = 0;
        while(j < rowsOfCurrentPage.size()) 
        {
            int value = rowsOfCurrentPage[j][colIndex];
            pq.push(make_pair((sortingMultiplicationFactor * value), j));
            j++;
        }
        
        vector<vector<int>> sortedRows;
        while(!pq.empty())
        {
            pair<int, int> p = pq.top();
            pq.pop();
            sortedRows.push_back(rowsOfCurrentPage[p.second]);
        }
        
        currPage.updateRows(sortedRows);
    }

    cout << "Individual page sorting done" << endl;
    cout << "Number of pages: " << this->blockCount << endl;
    cout << "sortBufferSize: " << sortBufferSize << endl;
    cout << "Number of runs: " << ceil(log2(this->blockCount) / log2(sortBufferSize)) << endl;

    priority_queue< pair<int, pair<int, int>> > pq2; // (max heap) (col val, (page index, row index))
    int cnt = 0;
    for(int runBlocks = 1; runBlocks < this->blockCount; runBlocks = runBlocks*sortBufferSize)
    {
        cnt++;
        cout << "Run: " << cnt << endl; 
        int mergeBlockCount = 0, writePageIndex = 0;
        for(int pageNum=0; pageNum < this->blockCount; pageNum += runBlocks)
        {
            // cout << "trying to fetch page: " << pageNum << endl;
            Page currPage = bufferManager.getPage(this->tableName, pageNum);
            // cout << "fetched page: " << pageNum << endl;
            int colVal = currPage.getRow(0)[colIndex];
            pq2.push(make_pair((sortingMultiplicationFactor * colVal), make_pair(pageNum, 0)));
            mergeBlockCount += 1;

            if(mergeBlockCount == sortBufferSize || ((pageNum + runBlocks) >= this->blockCount))
            {
                int pageCounter = 0;
                vector<vector<int>> sortedRows(this->maxRowsPerBlock, vector<int>(this->columnCount, 0));
                while(pq2.size() > 0)
                {
                    pair<int, pair<int, int>> p = pq2.top();
                    pq2.pop();
                    // cout << "Page no: " << p.second.first << ", ROW NO: " << p.second.second << endl;
                    Page topPage = bufferManager.getPage(this->tableName, p.second.first);
                    vector<int> topPageRow = topPage.getRow(p.second.second);
                    // for(auto it: topPageRow)
                    // {
                    //     cout << it << " ";
                    // }
                    // cout << endl;
                    sortedRows[pageCounter] = topPageRow;

                    int oldPageIndex = p.second.first;
                    int oldRowIndex = p.second.second;
                    int newPageIndex, newRowIndex;

                    if((oldRowIndex + 1) == topPage.rowCount)
                    {
                        newPageIndex = oldPageIndex + 1;
                        if(newPageIndex >= this->blockCount) 
                        {
                            newPageIndex = 0;
                        }
                        newRowIndex = 0;
                    }
                    else
                    {
                        newPageIndex = oldPageIndex;
                        newRowIndex = oldRowIndex + 1;
                    }

                    // cout << "newPageIndex: " << newPageIndex << ", newRowIndex: " << newRowIndex << endl;

                    if((newPageIndex == oldPageIndex) || ((newPageIndex != oldPageIndex) && 
                    (newPageIndex % runBlocks) != 0))
                    {
                        Page nextPage = bufferManager.getPage(this->tableName, newPageIndex);
                        vector<int> nextPageRow = nextPage.getRow(newRowIndex);
                        colVal = nextPageRow[colIndex];
                        pq2.push(make_pair(sortingMultiplicationFactor * colVal, make_pair(newPageIndex, newRowIndex)));
                    }
                    pageCounter += 1;

                    if(pageCounter == this->maxRowsPerBlock)
                    {
                        writePageForSort(writePageIndex, sortedRows, pageCounter);
                    }
                }
                if(pageCounter > 0)
                {
                    writePageForSort(writePageIndex, sortedRows, pageCounter);
                }
                mergeBlockCount = 0;
            }
        }

        // if(writePageIndex != this->blockCount) {
        //     return false;
        // }

        if(renameTempPagesForSort() == false)
        {
            return false;
        }
    }

    return true;

}

bool Table::updateTable(string updateColumnName, int operationType, int operand)
{
    // cout << "Executing updateTable" << endl;
    logger.log("Table::updateTable");

    auto it = find(this->columns.begin(), this->columns.end(), updateColumnName);
    if(it == this->columns.end())
    {
        return false;
    }

    int colIndex = it - this->columns.begin();
    // cout << "colIndex: " << colIndex << endl;

    // cout << "Number of pages: " << this->blockCount << endl;

    for(int pageNum = 0; pageNum < this->blockCount; pageNum++) 
    {
        struct flock lock;
        struct flock lock2;
        string file_loc = "../data/temp/" + this->tableName + "_Page" + to_string(pageNum);
        int fd;
        fd = open(file_loc.c_str(), O_WRONLY);
        int fd2;
        memset(&lock, 0, sizeof(lock));
        memset(&lock2, 0, sizeof(lock2));
        string str = "TEST";
        lock.l_type = F_WRLCK;

        fcntl(fd, F_GETLK, &lock2);
        if(lock2.l_type == F_UNLCK)
        {
            cout << "pageNum: " << pageNum << " is FREE, NO WAIT!!!" << endl;
        }
        else
        {
            cout << "pageNum: " << pageNum << " is already locked, WAITING!!!" << endl;
        }

        sleep(3);
        fcntl(fd, F_SETLKW, &lock);
        cout << "Locked the page: " << pageNum << endl;
        sleep(3);

        // Page currPage = Page(this->tableName, i);
        Page currPage = bufferManager.getPage(this->tableName, pageNum);
        vector<vector<int>> rowsOfCurrentPage = currPage.fetchRows();
        
        for(int i=0; i<rowsOfCurrentPage.size(); i++)
        {
            for(int j=0; j<rowsOfCurrentPage[0].size(); j++)
            {
                if(j == colIndex)
                {
                    if(operationType == 0) // multiply
                    {
                        rowsOfCurrentPage[i][j] *= operand;
                    }
                    else if(operationType == 1) // add
                    {
                        rowsOfCurrentPage[i][j] += operand;
                    }
                    else if(operationType == 2) // subtract
                    {
                        rowsOfCurrentPage[i][j] -= operand;
                    }
                }
            }
        }

        currPage.updateRows(rowsOfCurrentPage);
        string pageName = "../data/temp/" + this->tableName + "_Page" + to_string(pageNum);
        bufferManager.deletePageFromPool(pageName);

        // sleep(3);
        cout << "Updated page: " << pageNum << " successfuly!!" << endl;
        // sleep(3);

        lock.l_type = F_UNLCK;
        fcntl(fd, F_SETLKW, &lock);
        close(fd);
        cout << "UnLocked the page: " << pageNum << endl << endl;
    }
    
    return true;
}

bool Table::updateTableWithThreadAndMutexLock(string updateColumnName, int operationType, int operand, bool updateLock)
{
     auto th_id = this_thread::get_id();
    // cout << "Thread ID: "<< th_id << endl;

    // cout << "Executing updateTable" << " by Thread ID: "<< th_id << endl;
    logger.log("Table::updateTable");

    auto it = find(this->columns.begin(), this->columns.end(), updateColumnName);
    if(it == this->columns.end())
    {
        return false;
    }

    int colIndex = it - this->columns.begin();
    // cout << "colIndex: " << colIndex  << " by Thread ID: "<< th_id << endl;

    // cout << "Number of pages: " << this->blockCount  << " by Thread ID: "<< th_id << endl;

    if(updateLock == true)
    {
        // m.lock();
        for(int pageNum = 0; pageNum < this->blockCount; pageNum++) 
        {
            m.lock();
            // Page currPage = Page(this->tableName, i);
            cout << "Trying to fetch page: " << pageNum << " by Thread ID: "<< th_id << endl;
            Page currPage = bufferManager.getPage(this->tableName, pageNum);
            cout << "READ page: " << pageNum << " successfully!!" << " by Thread ID: "<< th_id << endl;
            vector<vector<int>> rowsOfCurrentPage = currPage.fetchRows();

            // for(int i=0; i<rowsOfCurrentPage.size(); i++)
            // {
            //     for(int j=0; j<rowsOfCurrentPage[0].size(); j++)
            //     {
            //         cout << rowsOfCurrentPage[i][j] << " ";
            //     }
            //     cout << endl;
            // }
            
            for(int i=0; i<rowsOfCurrentPage.size(); i++)
            {
                for(int j=0; j<rowsOfCurrentPage[0].size(); j++)
                {
                    if(j == colIndex)
                    {
                        if(operationType == 0) // multiply
                        {
                            rowsOfCurrentPage[i][j] *= operand;
                        }
                        else if(operationType == 1) // add
                        {
                            rowsOfCurrentPage[i][j] += operand;
                        }
                        else if(operationType == 2) // subtract
                        {
                            rowsOfCurrentPage[i][j] -= operand;
                        }
                    }
                }
            }

            currPage.updateRows(rowsOfCurrentPage);
            string pageName = "../data/temp/" + this->tableName + "_Page" + to_string(pageNum);
            bufferManager.deletePageFromPool(pageName);
            cout << "WROTE page: " << pageNum << " successfully!!" << " by Thread ID: "<< th_id << endl << endl;
            rowsOfCurrentPage = currPage.fetchRows();

            // for(int i=0; i<rowsOfCurrentPage.size(); i++)
            // {
            //     for(int j=0; j<rowsOfCurrentPage[0].size(); j++)
            //     {
            //         cout << rowsOfCurrentPage[i][j] << " ";
            //     }
            //     cout << endl;
            // }
            // cout << endl;
            sleep(2);
            m.unlock();
        }
        // m.unlock();
    }
    else
    {
        // m.lock();
        for(int pageNum = 0; pageNum < this->blockCount; pageNum++) 
        {
            cout << "Trying to fetch page: " << pageNum << " by Thread ID: "<< th_id << endl;
            Page currPage = bufferManager.getPage(this->tableName, pageNum);
            cout << "READ page: " << pageNum << " successfully!!" << " by Thread ID: "<< th_id << endl;
            vector<vector<int>> rowsOfCurrentPage = currPage.fetchRows();

            // for(int i=0; i<rowsOfCurrentPage.size(); i++)
            // {
            //     for(int j=0; j<rowsOfCurrentPage[0].size(); j++)
            //     {
            //         cout << rowsOfCurrentPage[i][j] << " ";
            //     }
            //     cout << endl;
            // }
            
            for(int i=0; i<rowsOfCurrentPage.size(); i++)
            {
                for(int j=0; j<rowsOfCurrentPage[0].size(); j++)
                {
                    if(j == colIndex)
                    {
                        if(operationType == 0) // multiply
                        {
                            rowsOfCurrentPage[i][j] *= operand;
                        }
                        else if(operationType == 1) // add
                        {
                            rowsOfCurrentPage[i][j] += operand;
                        }
                        else if(operationType == 2) // subtract
                        {
                            rowsOfCurrentPage[i][j] -= operand;
                        }
                    }
                }
            }

            currPage.updateRows(rowsOfCurrentPage);
            string pageName = "../data/temp/" + this->tableName + "_Page" + to_string(pageNum);
            bufferManager.deletePageFromPool(pageName);
            cout << "WROTE page: " << pageNum << " successfully!!" << " by Thread ID: "<< th_id << endl << endl;
            rowsOfCurrentPage = currPage.fetchRows();

            // for(int i=0; i<rowsOfCurrentPage.size(); i++)
            // {
            //     for(int j=0; j<rowsOfCurrentPage[0].size(); j++)
            //     {
            //         cout << rowsOfCurrentPage[i][j] << " ";
            //     }
            //     cout << endl;
            // }
            // cout << endl;
        }
    }

    return true;
}

bool Table::updateTableSimultaneously(string updateColumnName, int operationType, int operand, int updateNoOfConcurrentProcesses, bool updateLock)
{
    /* Runnning, only 2 threads */
    // std::thread man1(&Table::updateTable, this, updateColumnName, operationType, operand);
    // std::thread man2(&Table::updateTable, this, updateColumnName, operationType, operand);

    // man1.join();
	// man2.join();

    /* Runnning, Using multithreading */
    // vector<std::thread> vec(updateNoOfConcurrentProcesses);
    // for(int i=0; i<updateNoOfConcurrentProcesses; i++)
    // {
    //     vec[i] = thread(&Table::updateTableWithThreadAndMutexLock, this, updateColumnName, operationType, operand, updateLock);
    // }

    // for(int i=0; i<updateNoOfConcurrentProcesses; i++)
    // {
    //     vec[i].join();
    // }

    /* Runnning, Using future and async */
    std::vector<std::future<bool>> fut_vec;
    for (int i = 0; i <updateNoOfConcurrentProcesses; i++)
    {
        fut_vec.push_back(std::async(&Table::updateTableWithThreadAndMutexLock, this, updateColumnName, operationType, operand, updateLock));
    }
    
    for (int i = 0; i<updateNoOfConcurrentProcesses; i++)
    {
        if(fut_vec[i].get() == false)
        {
            return false;
        }
    }
    
    return true;
}