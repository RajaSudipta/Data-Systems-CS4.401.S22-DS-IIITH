```mermaid
graph TD
subgraph B+TREE
jucyx42[jucyx42<br/>size: 3<br/>]
ebprv20[ebprv20<br/>size: 3<br/>]
rgxap10[rgxap10<br/>size: 3<br/>]
lsggy4[lsggy4<br/>size: 2<br/>]
bmqbh2[bmqbh2<br/>size: 2<br/>1 2 ]
lsggy4-->|x <= 2|bmqbh2
gdaeo34[gdaeo34<br/>size: 2<br/>3 4 ]
lsggy4-->|2 < x|gdaeo34
rgxap10-->|x <= 4|lsggy4
ykoyh88[ykoyh88<br/>size: 2<br/>]
sirbh75[sirbh75<br/>size: 2<br/>5 6 ]
ykoyh88-->|x <= 6|sirbh75
uuqmo87[uuqmo87<br/>size: 3<br/>7 8 9 ]
ykoyh88-->|6 < x|uuqmo87
rgxap10-->|4 < x <= 9|ykoyh88
jwijw35[jwijw35<br/>size: 3<br/>]
yeyjg28[yeyjg28<br/>size: 2<br/>10 11 ]
jwijw35-->|x <= 11|yeyjg28
beljr84[beljr84<br/>size: 2<br/>12 13 ]
jwijw35-->|11 < x <= 13|beljr84
irfzv13[irfzv13<br/>size: 2<br/>14 15 ]
jwijw35-->|13 < x|irfzv13
rgxap10-->|9 < x|jwijw35
ebprv20-->|x <= 15|rgxap10
qzncq36[qzncq36<br/>size: 3<br/>]
qjxpq18[qjxpq18<br/>size: 3<br/>]
noewg17[noewg17<br/>size: 2<br/>16 17 ]
qjxpq18-->|x <= 17|noewg17
agvsm91[agvsm91<br/>size: 2<br/>18 19 ]
qjxpq18-->|17 < x <= 19|agvsm91
ruxsq56[ruxsq56<br/>size: 3<br/>20 21 22 ]
qjxpq18-->|19 < x|ruxsq56
qzncq36-->|x <= 22|qjxpq18
cwsyc79[cwsyc79<br/>size: 2<br/>]
lagmz78[lagmz78<br/>size: 3<br/>23 24 25 ]
cwsyc79-->|x <= 25|lagmz78
hlxzf63[hlxzf63<br/>size: 2<br/>26 27 ]
cwsyc79-->|25 < x|hlxzf63
qzncq36-->|22 < x <= 27|cwsyc79
qeqst57[qeqst57<br/>size: 2<br/>]
uniun43[uniun43<br/>size: 2<br/>28 29 ]
qeqst57-->|x <= 29|uniun43
oezlu24[oezlu24<br/>size: 3<br/>30 31 32 ]
qeqst57-->|29 < x|oezlu24
qzncq36-->|27 < x|qeqst57
ebprv20-->|15 < x <= 32|qzncq36
wzptt62[wzptt62<br/>size: 3<br/>]
ivkza27[ivkza27<br/>size: 2<br/>]
tgnkz26[tgnkz26<br/>size: 2<br/>33 34 ]
ivkza27-->|x <= 34|tgnkz26
pagfv68[pagfv68<br/>size: 2<br/>35 36 ]
ivkza27-->|34 < x|pagfv68
wzptt62-->|x <= 36|ivkza27
uffsy77[uffsy77<br/>size: 2<br/>]
qqvcd8[qqvcd8<br/>size: 2<br/>37 38 ]
uffsy77-->|x <= 38|qqvcd8
fnxxm76[fnxxm76<br/>size: 2<br/>39 40 ]
uffsy77-->|38 < x|fnxxm76
wzptt62-->|36 < x <= 40|uffsy77
mjhhv61[mjhhv61<br/>size: 2<br/>]
cdtqf60[cdtqf60<br/>size: 3<br/>41 42 43 ]
mjhhv61-->|x <= 43|cdtqf60
xysmi32[xysmi32<br/>size: 3<br/>44 45 46 ]
mjhhv61-->|43 < x|xysmi32
wzptt62-->|40 < x|mjhhv61
ebprv20-->|32 < x|wzptt62
jucyx42-->|x <= 46|ebprv20
uslcd41[uslcd41<br/>size: 2<br/>]
vyjdz19[vyjdz19<br/>size: 3<br/>]
yvlvc9[yvlvc9<br/>size: 2<br/>]
tgvhg3[tgvhg3<br/>size: 2<br/>47 48 ]
yvlvc9-->|x <= 48|tgvhg3
mkyrd89[mkyrd89<br/>size: 2<br/>49 50 ]
yvlvc9-->|48 < x|mkyrd89
vyjdz19-->|x <= 50|yvlvc9
yhgfd96[yhgfd96<br/>size: 2<br/>]
yttym95[yttym95<br/>size: 2<br/>51 52 ]
yhgfd96-->|x <= 52|yttym95
scvkn55[scvkn55<br/>size: 3<br/>53 54 55 ]
yhgfd96-->|52 < x|scvkn55
vyjdz19-->|50 < x <= 55|yhgfd96
qsplj66[qsplj66<br/>size: 3<br/>]
tbkok65[tbkok65<br/>size: 2<br/>56 57 ]
qsplj66-->|x <= 57|tbkok65
ljpcn21[ljpcn21<br/>size: 2<br/>58 59 ]
qsplj66-->|57 < x <= 59|ljpcn21
xyxvx82[xyxvx82<br/>size: 3<br/>60 61 62 ]
qsplj66-->|59 < x|xyxvx82
vyjdz19-->|55 < x|qsplj66
uslcd41-->|x <= 62|vyjdz19
uyudf67[uyudf67<br/>size: 3<br/>]
wvkca39[wvkca39<br/>size: 2<br/>]
vgjqm11[vgjqm11<br/>size: 2<br/>63 64 ]
wvkca39-->|x <= 64|vgjqm11
nilja97[nilja97<br/>size: 2<br/>65 66 ]
wvkca39-->|64 < x|nilja97
uyudf67-->|x <= 66|wvkca39
xroip98[xroip98<br/>size: 2<br/>]
hibwt50[hibwt50<br/>size: 2<br/>67 68 ]
xroip98-->|x <= 68|hibwt50
mopem85[mopem85<br/>size: 3<br/>69 70 71 ]
xroip98-->|68 < x|mopem85
uyudf67-->|66 < x <= 71|xroip98
jyapk51[jyapk51<br/>size: 3<br/>]
chdmj45[chdmj45<br/>size: 3<br/>72 73 74 ]
jyapk51-->|x <= 74|chdmj45
kzlcl38[kzlcl38<br/>size: 2<br/>75 76 ]
jyapk51-->|74 < x <= 76|kzlcl38
srcid93[srcid93<br/>size: 2<br/>77 78 ]
jyapk51-->|76 < x|srcid93
uyudf67-->|71 < x|jyapk51
uslcd41-->|62 < x|uyudf67
jucyx42-->|46 < x <= 78|uslcd41
ktuew73[ktuew73<br/>size: 2<br/>]
hiejo40[hiejo40<br/>size: 2<br/>]
qsrcp15[qsrcp15<br/>size: 2<br/>]
ypltu14[ypltu14<br/>size: 2<br/>79 80 ]
qsrcp15-->|x <= 80|ypltu14
aaskw49[aaskw49<br/>size: 3<br/>81 82 83 ]
qsrcp15-->|80 < x|aaskw49
hiejo40-->|x <= 83|qsrcp15
wlmat54[wlmat54<br/>size: 2<br/>]
ylsgh6[ylsgh6<br/>size: 2<br/>84 85 ]
wlmat54-->|x <= 85|ylsgh6
lllig53[lllig53<br/>size: 3<br/>86 87 88 ]
wlmat54-->|85 < x|lllig53
hiejo40-->|83 < x|wlmat54
ktuew73-->|x <= 88|hiejo40
iizxu72[iizxu72<br/>size: 2<br/>]
gilck31[gilck31<br/>size: 2<br/>]
irimq23[irimq23<br/>size: 3<br/>89 90 91 ]
gilck31-->|x <= 91|irimq23
qokpa30[qokpa30<br/>size: 2<br/>92 93 ]
gilck31-->|91 < x|qokpa30
iizxu72-->|x <= 93|gilck31
gqyqg71[gqyqg71<br/>size: 3<br/>]
mqsxu70[mqsxu70<br/>size: 2<br/>94 95 ]
gqyqg71-->|x <= 95|mqsxu70
hexuj47[hexuj47<br/>size: 3<br/>96 97 98 ]
gqyqg71-->|95 < x <= 98|hexuj47
ahqri81[ahqri81<br/>size: 2<br/>99 100 ]
gqyqg71-->|98 < x|ahqri81
iizxu72-->|93 < x|gqyqg71
ktuew73-->|88 < x|iizxu72
jucyx42-->|78 < x|ktuew73
end
```
```mermaid
graph LR
subgraph UNORDERED_HEAP
nwlrb1[nwlrb1<br/>size: 4<br/>36 99 46 60 ]
esudb5[esudb5<br/>size: 4<br/>85 83 91 78 ]
nwlrb1-->esudb5
mhrcr7[mhrcr7<br/>size: 4<br/>11 39 62 13 ]
esudb5-->mhrcr7
kqzfy12[kqzfy12<br/>size: 4<br/>14 29 80 74 ]
mhrcr7-->kqzfy12
wvytx16[wvytx16<br/>size: 4<br/>15 33 57 47 ]
kqzfy12-->wvytx16
eylcr22[eylcr22<br/>size: 4<br/>88 9 89 17 ]
wvytx16-->eylcr22
rjucm25[rjucm25<br/>size: 4<br/>52 30 32 1 ]
eylcr22-->rjucm25
styag29[styag29<br/>size: 4<br/>94 97 43 44 ]
rjucm25-->styag29
txgdw33[txgdw33<br/>size: 4<br/>2 4 79 27 ]
styag29-->txgdw33
plyan37[plyan37<br/>size: 4<br/>76 90 72 28 ]
txgdw33-->plyan37
xeoji44[xeoji44<br/>size: 4<br/>71 31 68 35 ]
plyan37-->xeoji44
gttkd46[gttkd46<br/>size: 4<br/>40 73 63 95 ]
xeoji44-->gttkd46
bgdfe48[bgdfe48<br/>size: 4<br/>84 19 81 66 ]
gttkd46-->bgdfe48
lvgef52[lvgef52<br/>size: 4<br/>87 54 10 25 ]
bgdfe48-->lvgef52
cdokj58[cdokj58<br/>size: 4<br/>5 45 26 98 ]
lvgef52-->cdokj58
vvugg59[vvugg59<br/>size: 4<br/>18 41 93 20 ]
cdokj58-->vvugg59
qcieo64[qcieo64<br/>size: 4<br/>56 55 67 34 ]
vvugg59-->qcieo64
aohxo69[aohxo69<br/>size: 4<br/>82 38 92 22 ]
qcieo64-->aohxo69
zvwic74[zvwic74<br/>size: 4<br/>3 37 23 58 ]
aohxo69-->zvwic74
oyyng80[oyyng80<br/>size: 4<br/>100 86 48 59 ]
zvwic74-->oyyng80
mrdrj83[mrdrj83<br/>size: 4<br/>12 70 77 6 ]
oyyng80-->mrdrj83
uumsj86[uumsj86<br/>size: 4<br/>8 49 69 61 ]
mrdrj83-->uumsj86
juhuf90[juhuf90<br/>size: 4<br/>53 16 24 7 ]
uumsj86-->juhuf90
imiwg92[imiwg92<br/>size: 4<br/>65 51 96 75 ]
juhuf90-->imiwg92
qjpfj94[qjpfj94<br/>size: 4<br/>21 50 64 42 ]
imiwg92-->qjpfj94
end
```
