/**
 * LeafNode represents leaf nodes in the B+Tree. The leaf node contains
 * <key, RecordPtrs> pairs. Each leaf (except root) have between ceil(FANOUT/2)
 * and FANOUT children.
 */

#ifndef BPTREE_LEAFNODE_HPP
#define BPTREE_LEAFNODE_HPP

#include "TreeNode.hpp"
#include <map>

class LeafNode : public TreeNode {
public:
    map<Key, RecordPtr> data_pointers;
    TreePtr next_leaf_ptr;
    // int size;

    //constructors
    explicit LeafNode(const TreePtr& tree_ptr = NULL_PTR);

    //helper functions
    Key max() override;
    Key min() override;


    //key functions
    TreePtr insert_key(const Key &key, const RecordPtr &record_ptr) override;// TO BE IMPLEMENTED
    void delete_key(const Key &key, TreePtr left_sibling, TreePtr right_sibling, 
                    TreePtr parent, int parent_index) override;// TO BE IMPLEMENTED
    Key getFirstElement();
    void range(ostream& os, const Key& min_key, const Key& max_key) const override;
    void export_node(ostream& os) override;
    void chart(ostream& os) override;
    void dump() const;
    void load();

    //I/O
    ostream& write(ostream& os) const override;
    istream& read(istream& is) override;
};


#endif //BPTREE_LEAFNODE_HPP
